package com.amirsam.tamarkozino.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import com.amirsam.tamarkozino.R

// ---------- پالت آبی پررنگ روی سفید ----------

val Blue600 = Color(0xFF1554C0)
val Blue400 = Color(0xFF2963C8)
val BlueLight = Color(0xFF5B8DEF)
val BlueContainer = Color(0xFFDCE7FB)
val BlueOnContainer = Color(0xFF0A2F6E)
val Ink = Color(0xFF16233A)
val InkSoft = Color(0xFF64748F)
val SurfaceVariant = Color(0xFFEEF2FA)
val White = Color(0xFFFFFFFF)

// ---------- فونت‌ها ----------

val vazirFont = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_bold, FontWeight.Bold)
)

val lalezarFont = FontFamily(
    Font(R.font.lalezar_regular, FontWeight.Normal)
)

private fun style(
    family: FontFamily,
    weight: FontWeight,
    size: Int,
    lineHeight: Int
): TextStyle = TextStyle(
    fontFamily = family,
    fontWeight = weight,
    fontSize = size.sp,
    lineHeight = lineHeight.sp
)

val AppTypography = Typography(
    displayLarge = style(lalezarFont, FontWeight.Normal, 64, 72),
    displayMedium = style(lalezarFont, FontWeight.Normal, 48, 56),
    displaySmall = style(lalezarFont, FontWeight.Normal, 40, 48),
    headlineLarge = style(lalezarFont, FontWeight.Normal, 30, 38),
    headlineMedium = style(lalezarFont, FontWeight.Normal, 26, 32),
    headlineSmall = style(lalezarFont, FontWeight.Normal, 22, 28),
    titleLarge = style(vazirFont, FontWeight.Bold, 20, 26),
    titleMedium = style(vazirFont, FontWeight.Bold, 17, 23),
    titleSmall = style(vazirFont, FontWeight.Bold, 15, 21),
    bodyLarge = style(vazirFont, FontWeight.Normal, 16, 24),
    bodyMedium = style(vazirFont, FontWeight.Normal, 14, 21),
    bodySmall = style(vazirFont, FontWeight.Normal, 12, 18),
    labelLarge = style(vazirFont, FontWeight.Medium, 14, 20),
    labelMedium = style(vazirFont, FontWeight.Medium, 12, 16),
    labelSmall = style(vazirFont, FontWeight.Medium, 11, 14)
)

private val LightScheme = lightColorScheme(
    primary = Blue600,
    onPrimary = White,
    primaryContainer = BlueContainer,
    onPrimaryContainer = BlueOnContainer,
    secondary = Blue400,
    onSecondary = White,
    secondaryContainer = Color(0xFFE0EAFB),
    onSecondaryContainer = BlueOnContainer,
    tertiary = Blue600,
    onTertiary = White,
    background = White,
    onBackground = Ink,
    surface = White,
    onSurface = Ink,
    surfaceVariant = SurfaceVariant,
    onSurfaceVariant = InkSoft,
    outline = Color(0xFFB9C6E3),
    outlineVariant = Color(0xFFDFE7F4),
    error = Color(0xFFC0344B),
    onError = White,
    errorContainer = Color(0xFFFBE3E7),
    onErrorContainer = Color(0xFF7A1F2E)
)

@Composable
fun TamarkozinoTheme(content: @Composable () -> Unit) {
    // کل اپ راست‌به‌چپ فارسی است
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = LightScheme,
            typography = AppTypography,
            content = content
        )
    }
}
