package com.amirsam.tamarkozino.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.amirsam.tamarkozino.lock.GuardianService

/**
 * بعد از روشن شدن دوباره‌ی گوشی:
 * - اگر قفل ابدی با محرک «ری‌استارت» فعال باشد → قفل باز می‌شود
 * - در غیر این صورت قفل فعال به همان شکل ادامه پیدا می‌کند
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs.lockActive) return
        if (Prefs.lockEternal) {
            val cfg = Prefs.eternalConfig()
            if (cfg.rebootUnlock) {
                LockManager.unlock(context, "خاموش و روشن شدن گوشی ♻️")
            } else {
                GuardianService.ensureRunning(context)
            }
        } else {
            GuardianService.ensureRunning(context)
        }
    }
}
