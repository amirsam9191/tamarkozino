package com.amirsam.tamarkozino.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.amirsam.tamarkozino.ai.AiClient
import com.amirsam.tamarkozino.core.AiConfig
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.core.Strictness
import com.amirsam.tamarkozino.util.nowMs
import com.amirsam.tamarkozino.util.sha256Hex
import com.amirsam.tamarkozino.util.toFa
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * تنظیمات کامل تمرکزینو
 */
@Composable
fun SettingsScreen(nav: NavController) {
    var tick by remember { mutableStateOf(0) }
    var etcfg by remember { mutableStateOf(Prefs.eternalConfig()) }
    var ai by remember { mutableStateOf(Prefs.aiConfig()) }
    var showPinSet by remember { mutableStateOf(false) }
    var showRiddleSet by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "تنظیمات ⚙️",
                fontFamily = com.amirsam.tamarkozino.ui.theme.lalezarFont,
                fontSize = 32.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = { nav.popBackStack() }) { Text("بازگشت") }
        }

        Spacer(Modifier.height(14.dp))

        // ---------- دسترسی‌ها ----------
        SectionCard(title = "دسترسی‌ها و مجوزها 🔑") {
            Text(
                "وضعیت همه‌ی دسترسی‌ها و فعال‌سازی‌شان (نمایش روی اپ‌ها، دسترسی‌پذیری، استفاده، DND و…)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { nav.navigate("onboarding") }) { Text("مدیریت دسترسی‌ها") }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- برنامه‌های مجاز ----------
        SectionCard(title = "برنامه‌های مجاز 📲") {
            Text(
                "${Prefs.allowedApps().size.toFa()} برنامه مجاز است. در زمان قفل فقط همین برنامه‌ها باز می‌شوند و آیکون‌شان در صفحه‌ی قفل دیده می‌شود. از منوی ریسنت‌ها هم فقط همین‌ها قابل دسترسی‌اند.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = { nav.navigate("allowed") }) { Text("مدیریت برنامه‌های مجاز") }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- هنگام قفل ----------
        SectionCard(title = "هنگام قفل 🔒") {
            SettingRow(
                title = "قطع اجباری صدا",
                sub = "صدا در طول قفل کاملاً قطع می‌شود و دوباره وصل‌شدنش مسدود است",
                checked = if (tick >= 0) Prefs.forceMute else false
            ) { Prefs.forceMute = it; tick++ }
            SettingRow(
                title = "بی‌صدا کردن زنگ تماس",
                sub = "زنگ تماس‌های ورودی هنگام قفل به‌صدا درنمی‌آید (DND)",
                checked = if (tick >= 0) Prefs.blockRinger else false
            ) { Prefs.blockRinger = it; tick++ }
            SettingRow(
                title = "حالت «پرواز»",
                sub = "بی‌صدا + بی‌زنگ + بی‌اعلان هنگام قفل. نکته‌ی صادقانه: اندروید به اپ‌های معمولی اجازه‌ی روشن‌کردن حالت هواپیمای واقعی را نمی‌دهد؛ این حالت، تمام صدا و زنگ و اعلان را قطع می‌کند ولی اینترنت قطع نمی‌شود.",
                checked = if (tick >= 0) Prefs.airplaneMode else false
            ) { Prefs.airplaneMode = it; tick++ }
            SettingRow(
                title = "نمایش اعلان‌ها در زمان قفل",
                sub = "اگر خاموش باشد، در طول قفل هیچ اعلانی برایت نمایش داده نمی‌شود؛ فقط وقتی قفل نیست اعلان‌ها می‌آیند",
                checked = if (tick >= 0) Prefs.notificationsInLock else true
            ) { Prefs.notificationsInLock = it; tick++ }
            SettingRow(
                title = "پاسخ به پیامک از روی اعلان",
                sub = "اگر روشن باشد، اپ پیامکِ پیش‌فرض در زمان قفل قابل باز شدن است تا جواب پیامک‌ها را بدهی",
                checked = if (tick >= 0) Prefs.smsFromNotification else false
            ) { Prefs.smsFromNotification = it; tick++ }
            SettingRow(
                title = "پایش تهاجمی",
                sub = "چرخه‌ی پوشش‌دهی سریع‌تر (~۱۵۰ms) با کمی هزینه‌ی باتری بیشتر",
                checked = if (tick >= 0) Prefs.aggressiveWatch else true
            ) { Prefs.aggressiveWatch = it; tick++ }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- پردازش‌های پس‌زمینه ----------
        SectionCard(title = "پردازش‌های پس‌زمینه 🧠") {
            Text(
                "به‌خواسته‌ی خودت: تمرکزینو پردازش‌های پس‌زمینه‌ی هیچ برنامه‌ای را نمی‌بندد و به هیچ‌وجه مزاحم آن‌ها نمی‌شود — اندروید اجازه‌ی چنین کاری را به اپ‌های معمولی نمی‌دهد و سلامت سرویس‌های در حال کار (مثل دانلودها و موسیقی) برای ما مهم است ✅",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---------- روش قفل ----------
        SectionCard(title = "روش قفل و رفتار دکمه‌ی برگشت 🧭") {
            RadioRow(
                title = "پوشش سریع (پیش‌فرض)",
                sub = "صفحه‌ی قفل در ~۱۰۰-۳۰۰ms روی برنامه‌ی غیرمجاز برمی‌گردد؛ دکمه‌ی ریسنت‌ها کار می‌کند و فقط برنامه‌های مجاز باقی می‌مانند",
                selected = if (tick >= 0) !Prefs.lockPinning else false
            ) { Prefs.lockPinning = false; tick++ }
            RadioRow(
                title = "سنجاق کردن صفحه (سخت‌گیرانه)",
                sub = "Screen Pinning سطح سیستم؛ هیچ دکمه‌ای کار نمی‌کند و خروج با تأیید سیستم است",
                selected = if (tick >= 0) Prefs.lockPinning else true
            ) { Prefs.lockPinning = true; tick++ }
            Spacer(Modifier.height(8.dp))
            RadioRow(
                title = "دکمه‌ی برگشت: بی‌اثر کامل",
                sub = "هیچ واکنشی نشان داده نمی‌شود",
                selected = if (tick >= 0) !Prefs.backMotivate else false
            ) { Prefs.backMotivate = false; tick++ }
            RadioRow(
                title = "دکمه‌ی برگشت: پیام انگیزشی",
                sub = "یک پیام کوتاه مثل «برگشتی؟ 😏 تمرکز هنوز ادامه داره…»",
                selected = if (tick >= 0) Prefs.backMotivate else true
            ) { Prefs.backMotivate = true; tick++ }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- ریست شمارنده‌ها ----------
        SectionCard(title = "ریست شمارنده‌ها 🔄") {
            SettingRow(
                title = "بعد از هر واکنش",
                sub = "پیش‌فرض: بعد از اجرای هر قاعده، شمارنده‌ی مصرف از نو شروع می‌شود",
                checked = if (tick >= 0) Prefs.resetAfterReaction else true
            ) { Prefs.resetAfterReaction = it; tick++ }
            SettingRow(
                title = "ریست روزانه در ساعت مشخص",
                sub = "مثلاً هر شب ساعت ۱۲:۰۰ شمارنده‌ها صفر شوند",
                checked = if (tick >= 0) Prefs.dailyResetEnabled else false
            ) { Prefs.dailyResetEnabled = it; tick++ }
            if (Prefs.dailyResetEnabled) {
                val resetMin = Prefs.dailyResetMinute
                NumberStepper(
                    label = "ساعتِ ریست",
                    value = resetMin / 60,
                    min = 0,
                    max = 23
                ) { h -> Prefs.dailyResetMinute = h * 60 + resetMin % 60; tick++ }
                NumberStepper(
                    label = "دقیقه‌ی ریست",
                    value = resetMin % 60,
                    min = 0,
                    max = 59,
                    step = 5
                ) { m -> Prefs.dailyResetMinute = (resetMin / 60) * 60 + m; tick++ }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- قفل ابدی ----------
        SectionCard(title = "قفل ابدی و روش‌های باز شدن ♾") {
            Text(
                "قفل ابدی تا وقتی یکی از محرک‌های زیر رخ ندهد باز نمی‌شود. می‌توانی چند راه را هم‌زمان فعال کنی.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            SettingRow(
                title = "📞 تماس ورودی",
                sub = "به‌محض زنگ خوردن گوشی، قفل باز می‌شود",
                checked = etcfg.callUnlock
            ) { etcfg = etcfg.copy(callUnlock = it); Prefs.setEternalConfig(etcfg); tick++ }
            SettingRow(
                title = "♻️ خاموش/روشن شدن گوشی",
                sub = "بعد از یک ری‌استارت، قفل باز می‌شود",
                checked = etcfg.rebootUnlock
            ) { etcfg = etcfg.copy(rebootUnlock = it); Prefs.setEternalConfig(etcfg); tick++ }
            SettingRow(
                title = "🔢 رمز",
                sub = if (etcfg.pinEnabled && etcfg.pinHash.isNotBlank()) "رمز تنظیم شده است" else "هنوز رمزی تنظیم نشده",
                checked = etcfg.pinEnabled
            ) { on ->
                etcfg = etcfg.copy(pinEnabled = on)
                Prefs.setEternalConfig(etcfg)
                if (on && etcfg.pinHash.isBlank()) showPinSet = true
                tick++
            }
            SettingRow(
                title = "🧩 معمای شخصی",
                sub = if (etcfg.riddleEnabled && etcfg.riddleQuestion.isNotBlank()) "معما: ${etcfg.riddleQuestion}" else "هنوز معمایی تنظیم نشده",
                checked = etcfg.riddleEnabled
            ) { on ->
                etcfg = etcfg.copy(riddleEnabled = on)
                Prefs.setEternalConfig(etcfg)
                if (on && etcfg.riddleQuestion.isBlank()) showRiddleSet = true
                tick++
            }
            SettingRow(
                title = "🤖 تأیید هوش مصنوعی",
                sub = "با گفتگو و ارسال عکس/مدرک، نگهبانِ AI قانع می‌شود تا قفل را باز کند",
                checked = etcfg.aiUnlock
            ) { etcfg = etcfg.copy(aiUnlock = it); Prefs.setEternalConfig(etcfg); tick++ }

            if (etcfg.pinEnabled && etcfg.pinHash.isNotBlank()) {
                OutlinedButton(onClick = { showPinSet = true }) { Text("تغییر رمز") }
                Spacer(Modifier.height(6.dp))
            }
            if (etcfg.riddleEnabled && etcfg.riddleQuestion.isNotBlank()) {
                OutlinedButton(onClick = { showRiddleSet = true }) { Text("تغییر معما") }
                Spacer(Modifier.height(6.dp))
            }

            Spacer(Modifier.height(4.dp))
            Text(
                "درجه‌ی سخت‌گیری هوش مصنوعی:",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
            )
            RadioRow(
                title = "آسان",
                sub = "با حداقل یک دلیل منطقی قانع می‌شود",
                selected = ai.strictness == Strictness.EASY
            ) { ai = ai.copy(strictness = Strictness.EASY); Prefs.setAiConfig(ai) }
            RadioRow(
                title = "متوسط",
                sub = "دلیل و یک مدرک می‌خواهد",
                selected = ai.strictness == Strictness.MEDIUM
            ) { ai = ai.copy(strictness = Strictness.MEDIUM); Prefs.setAiConfig(ai) }
            RadioRow(
                title = "سخت",
                sub = "حداقل دو مدرک روشن و سازگار می‌خواهد",
                selected = ai.strictness == Strictness.HARD
            ) { ai = ai.copy(strictness = Strictness.HARD); Prefs.setAiConfig(ai) }
        }

        Spacer(Modifier.height(12.dp))

        // ---------- هوش مصنوعی ----------
        SectionCard(title = "هوش مصنوعی — API سازگار با OpenAI 🤖") {
            AiField("Base URL", ai.baseUrl) { ai = ai.copy(baseUrl = it); Prefs.setAiConfig(ai) }
            AiField("مسیر chat completions", ai.chatPath) { ai = ai.copy(chatPath = it); Prefs.setAiConfig(ai) }
            AiField("مدل", ai.model) { ai = ai.copy(model = it); Prefs.setAiConfig(ai) }
            AiField(
                "کلید API",
                ai.apiKey,
                secret = true
            ) { ai = ai.copy(apiKey = it); Prefs.setAiConfig(ai) }
            AiField("هدر احراز", ai.authHeader) { ai = ai.copy(authHeader = it); Prefs.setAiConfig(ai) }
            AiField("طرح احراز", ai.authScheme) { ai = ai.copy(authScheme = it); Prefs.setAiConfig(ai) }
            AiField(
                "شرط/توضیح باز شدن قفل",
                ai.taskDescription
            ) { ai = ai.copy(taskDescription = it); Prefs.setAiConfig(ai) }

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        testing = true
                        testResult = ""
                        val cfg = ai
                        scope.launch(Dispatchers.IO) {
                            try {
                                val t0 = nowMs()
                                AiClient.chatBlocking(
                                    cfg,
                                    listOf(
                                        AiClient.ChatMessage(
                                            "user",
                                            "سلام، این فقط پیام تست اتصال است؛ لطفاً کوتاه جواب بده."
                                        )
                                    )
                                )
                                withContext(Dispatchers.Main) {
                                    testing = false
                                    testResult = "✅ ارتباط موفق — ${(((nowMs() - t0) / 1000L).toInt()).toFa()} ثانیه"
                                }
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    testing = false
                                    testResult = "⚠️ ${e.message}"
                                }
                            }
                        }
                    },
                    enabled = !testing
                ) { Text(if (testing) "در حال تست…" else "تست ارتباط") }
                OutlinedButton(
                    onClick = {
                        ai = AiConfig()
                        Prefs.setAiConfig(ai)
                        tick++
                        testResult = "مقادیر پیش‌فرض برگشت ✓"
                    }
                ) { Text("بازگردانی پیش‌فرض") }
            }
            if (testResult.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    testResult,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                "آدرس نهایی: ${ai.fullUrl()}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(12.dp))

        // ---------- درباره ----------
        SectionCard(title = "درباره ℹ️") {
            Text(
                "تمرکزینو نسخه ۱.۰.۰ — دوستِ تمرکز تو؛ با خواست خودت، بدون نظارت والدین 🧘",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "⚠️ یادآوری صادقانه: مثل هر اپ اندرویدی، راه نهایی فرار خاموش‌کردن گوشی و رفتن به حالت ایمن است؛ تمرکزینو جلوی خودش را عمداً سخت کرده اما هیچ اپی جلوی این را کامل نمی‌تواند بگیرد.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(10.dp))
        SignatureFooter()
    }

    if (showPinSet) {
        PinSetDialog(
            onDismiss = { showPinSet = false },
            onSave = { pin ->
                etcfg = etcfg.copy(pinHash = sha256Hex(pin), pinEnabled = true)
                Prefs.setEternalConfig(etcfg)
                showPinSet = false
                tick++
            }
        )
    }
    if (showRiddleSet) {
        RiddleSetDialog(
            initial = etcfg,
            onDismiss = { showRiddleSet = false },
            onSave = { q, a ->
                etcfg = etcfg.copy(riddleQuestion = q, riddleAnswer = a, riddleEnabled = true)
                Prefs.setEternalConfig(etcfg)
                showRiddleSet = false
                tick++
            }
        )
    }
}

@Composable
private fun AiField(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        OutlinedTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            visualTransformation = if (secret) PasswordVisualTransformation() else
                androidx.compose.ui.text.input.VisualTransformation.None,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun PinSetDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعیین رمز قفل ابدی 🔢") },
        text = {
            Column {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it; error = false },
                    label = { Text("رمز") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { confirm = it; error = false },
                    label = { Text("تکرار رمز") },
                    singleLine = true
                )
                if (error) {
                    Text(
                        "رمز و تکرارش یکسان نیست 🙈",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (pin.isNotBlank() && pin == confirm) onSave(pin) else error = true
                }
            ) { Text("ذخیره") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("بستن") } }
    )
}

@Composable
private fun RiddleSetDialog(
    initial: com.amirsam.tamarkozino.core.EternalConfig,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var q by remember { mutableStateOf(initial.riddleQuestion) }
    var a by remember { mutableStateOf(initial.riddleAnswer) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("معمای شخصی‌ات 🧩") },
        text = {
            Column {
                Text("معمایی که فقط خودت جوابش را می‌دانی")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it },
                    label = { Text("سؤال معما") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = a,
                    onValueChange = { a = it },
                    label = { Text("جواب") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (q.isNotBlank() && a.isNotBlank()) onSave(q, a)
                }
            ) { Text("ذخیره") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("بستن") } }
    )
}
