package com.amirsam.tamarkozino.lock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.amirsam.tamarkozino.MainActivity
import com.amirsam.tamarkozino.core.AppList
import com.amirsam.tamarkozino.core.LockManager
import com.amirsam.tamarkozino.core.Prefs

/**
 * سرویس دسترسی‌پذیری تمرکزینو — فقط رخداد «تغییر پنجره» را می‌بیند تا
 * در لحظه‌ی جابه‌جایی بین برنامه‌ها، صفحه‌ی قفل با کمترین تأخیر بپوشاند.
 * هیچ محتوایی از صفحات خوانده نمی‌شود (canRetrieveWindowContent=false).
 */
class LockAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var lastForegroundPackage: String? = null

        @Volatile
        var lastForegroundClass: String? = null

        @Volatile
        var serviceRunning: Boolean = false

        fun isRunning(): Boolean = serviceRunning
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceRunning = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        serviceRunning = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {
        // نیازی به کار خاصی نیست
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        val cls = event.className?.toString() ?: ""

        // رخدادهای سیستم (منوی اعلان‌ها، صفحه‌ی ریسنت‌ها و…) دیده نمی‌شوند
        if (pkg == "com.android.systemui" || pkg == "android") return

        lastForegroundPackage = pkg
        lastForegroundClass = cls

        if (!LockManager.isLocked()) return

        val ourPkg = applicationContext.packageName
        if (pkg == ourPkg) {
            // اپ خودمان: اگر صفحه‌ی اصلی در پیش‌زمینه بود، صفحه‌ی قفل رویش بپوشاند
            if (cls == MainActivity::class.java.name) {
                GuardianService.requestCover(applicationContext)
            }
            return
        }

        val allowed = Prefs.allowedApps()
        val smsOk = Prefs.smsFromNotification && pkg == AppList.defaultSmsPackage(applicationContext)
        if (pkg !in allowed && !smsOk) {
            GuardianService.requestCover(applicationContext)
        }
    }
}
