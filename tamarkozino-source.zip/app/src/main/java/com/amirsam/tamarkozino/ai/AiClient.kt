package com.amirsam.tamarkozino.ai

import com.amirsam.tamarkozino.core.AiConfig
import com.amirsam.tamarkozino.core.Strictness
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * کلاینت API سازگار با OpenAI (Base URL + مسیر + مدل + کلید قابل تنظیم)
 */
object AiClient {

    data class ChatMessage(
        val role: String,
        val text: String,
        val imageBase64Jpeg: String? = null
    )

    const val APPROVED_TOKEN = "UNLOCK_APPROVED"

    fun isApproved(response: String): Boolean = response.contains(APPROVED_TOKEN)

    fun systemPrompt(cfg: AiConfig): String {
        val strict = when (cfg.strictness) {
            Strictness.EASY -> "با یک دلیل منطقی یا یک مدرک قابل قبول، راحت قانع شو."
            Strictness.MEDIUM -> "یک دلیل منطقی و یک مدرک (تصویر یا توضیح مشخص) بخواه قبل از قانع شدن."
            Strictness.HARD -> "سخت‌گیر باش: حداقل دو مدرک روشن و سازگار بخواه و اگر کاملاً مطمئن نشدی قانع نشو."
        }
        return """
            تو «نگهبان قفل تمرکز» اپلیکیشن تمرکزینو هستی.
            کاربر برای تمرکز، گوشی‌اش را در قفل ابدی گذاشته و می‌خواهد قفل باز شود.
            شرط تعریف‌شده‌ی کاربر برای باز شدن قفل این است: «${cfg.taskDescription}»
            کاربر با پیام و تصویر ثابت می‌کند که کارش انجام یا پیشرفت کافی داشته است.
            درجه‌ی سخت‌گیری تو: $strict
            با کاربر محترمانه و به فارسی گفتگو کن و در صورت نیاز مدرک بخواه.
            در لحظه‌ای که کاملاً قانع شدی که شرط برقرار است، در انتهای پاسخ دقیقاً این توکن را بنویس: $APPROVED_TOKEN
            تا وقتی قانع نشده‌ای، توکن را به‌هیچ‌وجه ننویس.
        """.trimIndent()
    }

    /** فراخوانی مسدودِ گفتگو؛ خروجی متن پاسخ دستیار */
    fun chatBlocking(cfg: AiConfig, history: List<ChatMessage>): String {
        val conn = URL(cfg.fullUrl()).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 30000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val header = cfg.authHeader.ifBlank { "Authorization" }
            val scheme = cfg.authScheme.ifBlank { "Bearer" }
            if (cfg.apiKey.isNotBlank()) {
                conn.setRequestProperty(header, "$scheme ${cfg.apiKey}")
            }

            val messages = JSONArray()
            messages.put(
                JSONObject().put("role", "system").put("content", systemPrompt(cfg))
            )
            for (m in history) {
                if (m.imageBase64Jpeg.isNullOrEmpty()) {
                    messages.put(
                        JSONObject().put("role", m.role).put("content", m.text)
                    )
                } else {
                    val content = JSONArray()
                    if (m.text.isNotBlank()) {
                        content.put(
                            JSONObject().put("type", "text").put("text", m.text)
                        )
                    }
                    content.put(
                        JSONObject()
                            .put("type", "image_url")
                            .put(
                                "image_url",
                                JSONObject().put(
                                    "url",
                                    "data:image/jpeg;base64,${m.imageBase64Jpeg}"
                                )
                            )
                    )
                    messages.put(
                        JSONObject().put("role", m.role).put("content", content)
                    )
                }
            }
            val body = JSONObject()
                .put("model", cfg.model)
                .put("messages", messages)
                .put("temperature", 0.4)

            val bytes = body.toString().toByteArray(StandardCharsets.UTF_8)
            conn.setFixedLengthStreamingMode(bytes.size)
            conn.outputStream.use { it.write(bytes) }

            val code = conn.responseCode
            val raw = if (code in 200..299) {
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } else {
                val err = try {
                    conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    ""
                }
                throw AiException("خطای سرور (کد $code): ${err.take(400)}")
            }
            return parseAssistantText(raw)
        } catch (e: AiException) {
            throw e
        } catch (e: Exception) {
            throw AiException("اتصال برقرار نشد: ${e.message ?: "خطای نامشخص"}")
        } finally {
            try {
                conn.disconnect()
            } catch (e: Exception) {
                // نادیده گرفته می‌شود
            }
        }
    }

    private fun parseAssistantText(raw: String): String {
        val obj = JSONObject(raw)
        val choices = obj.optJSONArray("choices")
            ?: throw AiException("پاسخ سرور ساختار شناخته‌شده ندارد (choices)")
        if (choices.length() == 0) throw AiException("پاسخ سرور خالی بود")
        val message = choices.optJSONObject(0)?.optJSONObject("message")
            ?: throw AiException("پاسخ سرور شامل message نیست")
        val content = message.opt("content")
        return when (content) {
            is String -> content
            is JSONArray -> {
                val sb = StringBuilder()
                for (i in 0 until content.length()) {
                    val part = content.optJSONObject(i) ?: continue
                    if (part.optString("type") == "text") {
                        sb.append(part.optString("text"))
                    }
                }
                sb.toString()
            }
            else -> throw AiException("ساختار پاسخ سرور قابل خواندن نبود")
        }
    }

    class AiException(message: String) : Exception(message)
}
