package com.amirsam.tamarkozino.lock

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.amirsam.tamarkozino.core.LockManager
import com.amirsam.tamarkozino.ui.NumberStepper
import com.amirsam.tamarkozino.ui.SignatureFooter
import com.amirsam.tamarkozino.ui.theme.Blue600
import com.amirsam.tamarkozino.ui.theme.TamarkozinoTheme
import com.amirsam.tamarkozino.util.formatHm

/**
 * صفحه‌ی درخواست: «سؤال بله/خیر» یا «انتخاب زمان اجباری»
 */
class PromptActivity : ComponentActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val EXTRA_DURATION = "duration"
        const val EXTRA_MIN = "min"
        const val EXTRA_MAX = "max"
        const val EXTRA_TITLE = "title"
        const val MODE_ASK = 1
        const val MODE_FORCED_CHOOSE = 2

        fun showAsk(context: Context, durationMinutes: Int, title: String) {
            val i = Intent(context, PromptActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(EXTRA_MODE, MODE_ASK)
                .putExtra(EXTRA_DURATION, durationMinutes)
                .putExtra(EXTRA_TITLE, title)
            try {
                context.startActivity(
                    i,
                    ActivityOptions.makeCustomAnimation(context, 0, 0).toBundle()
                )
            } catch (e: Exception) {
                // نادیده گرفته می‌شود
            }
        }

        fun showForcedChoose(
            context: Context,
            minMinutes: Int,
            maxMinutes: Int,
            title: String
        ) {
            val i = Intent(context, PromptActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra(EXTRA_MODE, MODE_FORCED_CHOOSE)
                .putExtra(EXTRA_MIN, minMinutes)
                .putExtra(EXTRA_MAX, maxMinutes)
                .putExtra(EXTRA_TITLE, title)
            try {
                context.startActivity(
                    i,
                    ActivityOptions.makeCustomAnimation(context, 0, 0).toBundle()
                )
            } catch (e: Exception) {
                // نادیده گرفته می‌شود
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        windowSetup()
        val mode = intent.getIntExtra(EXTRA_MODE, MODE_ASK)
        val duration = intent.getIntExtra(EXTRA_DURATION, 60)
        val min = intent.getIntExtra(EXTRA_MIN, 15).coerceAtLeast(1)
        val max = intent.getIntExtra(EXTRA_MAX, 120).coerceAtLeast(min)
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "تمرکزینو"
        setContent {
            TamarkozinoTheme {
                BackHandler {
                    // در صفحه‌ی اجباری و درخواست، برگشت بی‌اثر است
                }
                PromptContent(
                    mode = mode,
                    initialDuration = duration,
                    minMinutes = min,
                    maxMinutes = max,
                    title = title,
                    onStart = { minutes ->
                        LockManager.startTimedLock(this, minutes, title)
                        finish()
                    },
                    onCancel = { finish() }
                )
            }
        }
    }

    private fun windowSetup() {
        if (Build.VERSION.SDK_INT >= 27) {
            window.setShowWhenLocked(true)
            window.setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // بی‌اثر
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
private fun PromptContent(
    mode: Int,
    initialDuration: Int,
    minMinutes: Int,
    maxMinutes: Int,
    title: String,
    onStart: (Int) -> Unit,
    onCancel: () -> Unit
) {
    var minutes by remember {
        mutableStateOf(initialDuration.coerceIn(minMinutes, maxMinutes))
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        Box(
            modifier = Modifier
                .offset(x = (-60).dp, y = (-90).dp)
                .size(240.dp)
                .background(
                    Brush.radialGradient(listOf(Color(0x221554C0), Color.Transparent)),
                    CircleShape
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(50)
            ) {
                Text(
                    "  $title  ",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            }

            if (mode == PromptActivity.MODE_ASK) {
                Text("⏰", fontSize = 54.sp)
                Text(
                    "وقتِ تمرکزه!",
                    fontFamily = com.amirsam.tamarkozino.ui.theme.lalezarFont,
                    fontSize = 32.sp,
                    color = Blue600
                )
                Text(
                    "می‌خوای گوشی رو قفل کنم؟ 🧘",
                    style = MaterialTheme.typography.bodyLarge
                )
            } else {
                Text("⏳", fontSize = 54.sp)
                Text(
                    "قفل اجباری",
                    fontFamily = com.amirsam.tamarkozino.ui.theme.lalezarFont,
                    fontSize = 32.sp,
                    color = Blue600
                )
                Text(
                    "مدت قفل رو انتخاب کن (بین ${minMinutes.formatHm()} و ${maxMinutes.formatHm()})",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(6.dp))

            NumberStepper(
                label = "ساعت",
                value = minutes / 60,
                min = 0,
                max = (maxMinutes / 60).coerceAtLeast(0)
            ) { h ->
                minutes = (h * 60 + minutes % 60).coerceIn(minMinutes, maxMinutes)
            }
            NumberStepper(
                label = "دقیقه",
                value = minutes % 60,
                min = 0,
                max = 59,
                step = 5
            ) { m ->
                minutes = ((minutes / 60) * 60 + m).coerceIn(minMinutes, maxMinutes)
            }

            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    "قفل برای ${minutes.formatHm()} 🧘",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            Spacer(Modifier.height(10.dp))

            if (mode == PromptActivity.MODE_ASK) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                        Text("✋ فعلاً نه")
                    }
                    Button(onClick = { onStart(minutes) }, modifier = Modifier.weight(1f)) {
                        Text("🔒 آره، قفل کن")
                    }
                }
            } else {
                Button(
                    onClick = { onStart(minutes) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("🔒 قفل کن") }
                Text(
                    "این مرحله قابل لغو نیست ⛔",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(12.dp))
            SignatureFooter()
        }
    }
}
