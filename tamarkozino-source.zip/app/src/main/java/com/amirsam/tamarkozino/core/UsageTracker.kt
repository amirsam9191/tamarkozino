package com.amirsam.tamarkozino.core

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import com.amirsam.tamarkozino.util.dayKeyOf
import com.amirsam.tamarkozino.util.minuteOfDayOf
import com.amirsam.tamarkozino.util.nowMs
import java.util.Calendar

/**
 * ردیاب استفاده: زمان هر برنامه، روشن بودن صفحه و تعداد روشن‌کردن گوشی
 */
object UsageTracker {

    private val EXCLUDED = setOf("com.android.systemui", "com.amirsam.tamarkozino", "android")

    fun hasUsageAccess(context: Context): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_PACKAGE_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    private fun usm(context: Context): UsageStatsManager? = try {
        context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
    } catch (e: Exception) {
        null
    }

    fun ensureEpoch() {
        if (Prefs.resetEpochMs == 0L) Prefs.resetEpochMs = nowMs()
    }

    /** بازه‌ی امروزِ یک پنجره‌ی ساعتی به میلی‌ثانیه */
    private fun windowTodayEpoch(windowStartMin: Int, windowEndMin: Int): LongArray {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, windowStartMin / 60)
        cal.set(Calendar.MINUTE, windowStartMin % 60)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        return longArrayOf(start, start + (windowEndMin - windowStartMin) * 60_000L)
    }

    /** استفاده از مجموعه‌ی برنامه‌ها از زمان ریست، در پنجره‌ی اختیاری */
    fun appUsageMs(context: Context, pkgs: Set<String>, windowStartMin: Int?, windowEndMin: Int?): Long {
        ensureEpoch()
        val since = Prefs.resetEpochMs
        val now = nowMs()
        val winStart: Long
        val winEnd: Long
        if (windowStartMin != null && windowEndMin != null) {
            val win = windowTodayEpoch(windowStartMin, windowEndMin)
            winStart = win[0]
            winEnd = win[1]
        } else {
            winStart = since
            winEnd = now
        }
        val clipStart = maxOf(since, winStart)
        val clipEnd = minOf(now, winEnd)
        if (clipStart >= clipEnd) return 0L
        return sumForeground(context, since, now, pkgs, clipStart, clipEnd)
    }

    /** استفاده کل گوشی (همه‌ی برنامه‌ها به‌جز خودِ تمرکزینو و سیستم) */
    fun totalUsageMs(context: Context, windowStartMin: Int?, windowEndMin: Int?): Long {
        return appUsageMsInner(context, null, windowStartMin, windowEndMin)
    }

    private fun appUsageMsInner(context: Context, pkgs: Set<String>?, windowStartMin: Int?, windowEndMin: Int?): Long {
        ensureEpoch()
        val since = Prefs.resetEpochMs
        val now = nowMs()
        val winStart: Long
        val winEnd: Long
        if (windowStartMin != null && windowEndMin != null) {
            val win = windowTodayEpoch(windowStartMin, windowEndMin)
            winStart = win[0]
            winEnd = win[1]
        } else {
            winStart = since
            winEnd = now
        }
        val clipStart = maxOf(since, winStart)
        val clipEnd = minOf(now, winEnd)
        if (clipStart >= clipEnd) return 0L
        return sumForeground(context, since, now, pkgs, clipStart, clipEnd)
    }

    /** جمع بازه‌های پیش‌روی برنامه‌ها بر اساس رخدادهای UsageStats */
    private fun sumForeground(
        context: Context,
        from: Long,
        to: Long,
        pkgs: Set<String>?,
        clipStart: Long,
        clipEnd: Long
    ): Long {
        val usm = usm(context) ?: return 0L
        val events = try {
            usm.queryEvents(from, to)
        } catch (e: Exception) {
            null
        } ?: return 0L
        val ev = UsageEvents.Event()
        val lastResume = HashMap<String, Long>()
        var total = 0L

        fun addInterval(pkg: String, start: Long, end: Long) {
            if (pkg in EXCLUDED) return
            if (pkgs != null && pkg !in pkgs) return
            val s = start.coerceAtLeast(clipStart).coerceAtLeast(from)
            val e = end.coerceAtMost(clipEnd).coerceAtMost(to)
            if (e > s) total += e - s
        }

        while (events.hasNextEvent()) {
            try {
                events.getNextEvent(ev)
            } catch (e: Exception) {
                break
            }
            val pkg = ev.packageName ?: continue
            when (ev.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> {
                    lastResume[pkg] = ev.timeStamp
                }
                UsageEvents.Event.ACTIVITY_PAUSED -> {
                    val started = lastResume.remove(pkg) ?: continue
                    addInterval(pkg, started, ev.timeStamp)
                }
            }
        }
        for ((pkg, started) in lastResume) {
            addInterval(pkg, started, to)
        }
        return total
    }

    /** روشن بودن صفحه از زمان ریست در پنجره‌ی اختیاری */
    fun screenOnMs(windowStartMin: Int?, windowEndMin: Int?): Long {
        ensureEpoch()
        val since = Prefs.resetEpochMs
        val now = nowMs()
        val winStart: Long
        val winEnd: Long
        if (windowStartMin != null && windowEndMin != null) {
            val win = windowTodayEpoch(windowStartMin, windowEndMin)
            winStart = win[0]
            winEnd = win[1]
        } else {
            winStart = since
            winEnd = now
        }
        val clipStart = maxOf(since, winStart)
        val clipEnd = minOf(now, winEnd)
        if (clipStart >= clipEnd) return 0L

        val intervals = Prefs.screenIntervals().toMutableList()
        val openSince = Prefs.screenOpenSince
        if (openSince > 0) intervals.add(longArrayOf(openSince, now))

        var total = 0L
        for (iv in intervals) {
            val s = iv[0].coerceAtLeast(clipStart)
            val e = iv[1].coerceAtMost(clipEnd)
            if (e > s) total += e - s
        }
        return total
    }

    /** تعداد روشن‌کردن صفحه از زمان ریست در پنجره‌ی اختیاری */
    fun unlockCount(windowStartMin: Int?, windowEndMin: Int?): Int {
        ensureEpoch()
        val since = Prefs.resetEpochMs
        val times = Prefs.unlockTimes()
        if (windowStartMin == null || windowEndMin == null) {
            return times.count { it >= since }
        }
        val win = windowTodayEpoch(windowStartMin, windowEndMin)
        return times.count { t -> t >= since && t >= win[0] && t < win[1] }
    }

    /** ریست روزانه شمارنده‌ها در صورت رسیدن به ساعت تنظیم‌شده */
    fun maybeDailyReset(): Boolean {
        if (!Prefs.dailyResetEnabled) return false
        val now = nowMs()
        val day = dayKeyOf(now)
        if (Prefs.lastDailyResetDay == day) return false
        val minute = minuteOfDayOf(now)
        if (minute >= Prefs.dailyResetMinute) {
            Prefs.resetCounters(now)
            Prefs.lastDailyResetDay = day
            return true
        }
        return false
    }
}
