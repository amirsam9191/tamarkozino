package com.amirsam.tamarkozino.core

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.provider.Telephony
import java.util.Collections

/**
 * فهرست برنامه‌های نصب‌شده به‌همراه آیکون‌ها (کش‌شده)
 */
object AppList {

    data class AppInfo(
        val pkg: String,
        val label: String,
        val icon: Bitmap?
    )

    @Volatile
    private var cache: List<AppInfo>? = null

    @Volatile
    private var byPkg: Map<String, AppInfo>? = null

    private val lock = Object()

    fun ensureLoaded(context: Context): List<AppInfo> {
        cache?.let { return it }
        synchronized(lock) {
            cache?.let { return it }
            val loaded = load(context)
            cache = loaded
            byPkg = loaded.associateBy { it.pkg }
            return loaded
        }
    }

    fun invalidate() {
        synchronized(lock) {
            cache = null
            byPkg = null
        }
    }

    fun iconOf(context: Context, pkg: String): Bitmap? {
        if (byPkg == null) ensureLoaded(context)
        return byPkg?.get(pkg)?.icon
    }

    fun labelOf(context: Context, pkg: String): String? {
        if (byPkg == null) ensureLoaded(context)
        return byPkg?.get(pkg)?.label
    }

    /** بسته‌ی پیش‌فرض پیامک گوشی */
    fun defaultSmsPackage(context: Context): String? {
        return try {
            @Suppress("DEPRECATION")
            Telephony.Sms.getDefaultSmsPackage(context)
        } catch (e: Exception) {
            null
        }
    }

    private fun load(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ourPkg = context.packageName
        val ris = try {
            pm.queryIntentActivities(intent, 0)
        } catch (e: Exception) {
            emptyList()
        }
        val list = mutableListOf<AppInfo>()
        for (ri in ris) {
            val info = ri.activityInfo ?: continue
            val pkg = info.applicationInfo?.packageName ?: info.packageName ?: continue
            if (pkg == ourPkg) continue
            if (list.any { it.pkg == pkg }) continue
            val label = try {
                ri.loadLabel(pm).toString()
            } catch (e: Exception) {
                pkg
            }
            val icon = try {
                drawableToBitmap(ri.loadIcon(pm), 108)
            } catch (e: Exception) {
                null
            }
            list.add(AppInfo(pkg, label, icon))
        }
        Collections.sort(list) { a, b -> a.label.compareTo(b.label) }
        return list
    }

    private fun drawableToBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val half = sizePx / 2f
        val intrinsicW = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 108
        val intrinsicH = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 108
        drawable.setBounds(
            (half - intrinsicW / 8f).toInt(),
            (half - intrinsicH / 8f).toInt(),
            (half + intrinsicW / 8f).toInt(),
            (half + intrinsicH / 8f).toInt()
        )
        drawable.draw(canvas)
        return bmp
    }
}
