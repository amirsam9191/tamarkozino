package com.amirsam.tamarkozino.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.amirsam.tamarkozino.core.AppList
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.core.ReactionKind
import com.amirsam.tamarkozino.core.Rule
import com.amirsam.tamarkozino.core.TriggerKind
import com.amirsam.tamarkozino.util.formatHm
import com.amirsam.tamarkozino.util.toFa
import com.amirsam.tamarkozino.util.toTimeLabel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * قوانین هوشمند: محرک → واکنش
 */
@Composable
fun RulesScreen(nav: NavController) {
    val context = LocalContext.current
    var rules by remember { mutableStateOf(Prefs.rules()) }
    var editing by remember { mutableStateOf<Rule?>(null) }

    fun save() {
        Prefs.setRules(rules)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "قوانین هوشمند ⚖️",
                fontFamily = com.amirsam.tamarkozino.ui.theme.lalezarFont,
                fontSize = 30.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = { nav.popBackStack() }) { Text("بازگشت") }
        }
        Text(
            "اگر محرک رخ بدهد، واکنش اجرا می‌شود؛ بعد از واکنش، شمارنده‌ها مطابق تنظیمات ریست می‌شوند.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(14.dp))

        UsageAccessWarning(context)

        if (rules.isEmpty()) {
            Text(
                "هنوز قانونی نداری. مثال: «اگر بین ۱۵:۳۰ تا ۱۶:۳۰ بیشتر از ۲۰ دقیقه از اینستاگرام استفاده کردم → گوشی برای ۱ ساعت قفل شود» 🔧",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        rules.forEach { r ->
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            r.trigger.label,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = r.enabled,
                            onCheckedChange = { on ->
                                rules = rules.map {
                                    if (it.id == r.id) it.copy(enabled = on) else it
                                }.toMutableList()
                                save()
                            }
                        )
                    }
                    Text(ruleSummary(r, context), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editing = r }) { Text("ویرایش ✏️") }
                        OutlinedButton(onClick = {
                            rules = (rules.filter { it.id != r.id }).toMutableList()
                            save()
                        }) { Text("حذف 🗑") }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { editing = Rule() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("افزودن قانون ➕") }

        Spacer(Modifier.height(10.dp))
        SignatureFooter()
    }

    editing?.let { r ->
        RuleEditorDialog(
            initial = r,
            onDismiss = { editing = null },
            onSave = { saved ->
                rules = (rules.filter { it.id != saved.id } + saved).toMutableList()
                save()
                editing = null
            }
        )
    }
}

@Composable
private fun UsageAccessWarning(context: android.content.Context) {
    var hasAccess by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            hasAccess = com.amirsam.tamarkozino.core.UsageTracker.hasUsageAccess(context)
        }
    }
    if (!hasAccess) {
        Surface(
            color = MaterialTheme.colorScheme.errorContainer,
            shape = RoundedCornerShape(18.dp)
        ) {
            Text(
                "⚠️ «دسترسی وضعیت استفاده» فعال نیست؛ قوانینِ مصرفِ برنامه‌ها کار نمی‌کنند. از صفحه‌ی دسترسی‌ها فعالش کن.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.padding(12.dp)
            )
        }
        Spacer(Modifier.height(10.dp))
    }
}

fun ruleSummary(r: Rule, context: android.content.Context): String {
    val trigger = when {
        r.trigger.usesApps -> {
            val names = r.apps.take(3).map {
                AppList.labelOf(context, it) ?: it.substringAfterLast('.')
            }.joinToString("، ")
            "برنامه‌ها: ${if (r.apps.isEmpty()) "همه" else names}${if (r.apps.size > 3) " و…" else ""} — "
        }
        else -> ""
    }
    val condition = if (r.trigger.usesCount) {
        "بیش از ${r.unlockThreshold.toFa()} بار"
    } else {
        "بیش از ${r.thresholdMinutes.toFa()} دقیقه"
    }
    val window = if (r.trigger.usesWindow) {
        " در بازه‌ی ${r.windowStart.toTimeLabel()} تا ${r.windowEnd.toTimeLabel()}"
    } else " در روز"
    val reaction = when (r.reaction) {
        ReactionKind.TIMED -> "قفل برای ${r.lockMinutes.formatHm()}"
        ReactionKind.FORCED_CHOOSE -> "صفحه‌ی انتخاب زمان اجباری (بین ${r.forcedMinMinutes.formatHm()} و ${r.forcedMaxMinutes.formatHm()})"
        ReactionKind.ETERNAL -> "قفل ابدی ♾"
    }
    return "اگر $trigger$condition$window → $reaction"
}

@Composable
private fun RuleEditorDialog(
    initial: Rule,
    onDismiss: () -> Unit,
    onSave: (Rule) -> Unit
) {
    val context = LocalContext.current
    var r by remember { mutableStateOf(initial) }
    var showTriggerPicker by remember { mutableStateOf(false) }
    var showReactionPicker by remember { mutableStateOf(false) }
    var showAppsPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ویرایش قانون ⚖️") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text("محرک: ${r.trigger.label}", style = MaterialTheme.typography.titleSmall)
                        Text(ruleSummary(r, context), style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(onClick = { showTriggerPicker = true }) {
                            Text("تغییر محرک")
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                if (r.trigger.usesApps) {
                    OutlinedButton(onClick = { showAppsPicker = true }) {
                        Text("انتخاب برنامه‌ها (${r.apps.size.toFa()}) 📲")
                    }
                    Spacer(Modifier.height(8.dp))
                }
                if (r.trigger.usesMinutes) {
                    NumberStepper(
                        label = "آستانه (دقیقه)",
                        value = r.thresholdMinutes,
                        min = 5,
                        max = 600,
                        step = 5
                    ) { r = r.copy(thresholdMinutes = it) }
                }
                if (r.trigger.usesCount) {
                    NumberStepper(
                        label = "آستانه (تعداد بار)",
                        value = r.unlockThreshold,
                        min = 1,
                        max = 50
                    ) { r = r.copy(unlockThreshold = it) }
                }
                if (r.trigger.usesWindow) {
                    TimeSteppers("از ساعت", r.windowStart) { r = r.copy(windowStart = it) }
                    TimeSteppers("تا ساعت", r.windowEnd) { r = r.copy(windowEnd = it) }
                }

                Spacer(Modifier.height(10.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text("واکنش: ${r.reaction.label}", style = MaterialTheme.typography.titleSmall)
                        OutlinedButton(onClick = { showReactionPicker = true }) {
                            Text("تغییر واکنش")
                        }
                        Spacer(Modifier.height(8.dp))
                        when (r.reaction) {
                            ReactionKind.TIMED -> {
                                NumberStepper(
                                    label = "مدت قفل (دقیقه)",
                                    value = r.lockMinutes,
                                    min = 5,
                                    max = 480,
                                    step = 5
                                ) { r = r.copy(lockMinutes = it) }
                            }
                            ReactionKind.FORCED_CHOOSE -> {
                                NumberStepper(
                                    label = "حداقل دقیقه‌ی انتخاب",
                                    value = r.forcedMinMinutes,
                                    min = 5,
                                    max = 240,
                                    step = 5
                                ) { r = r.copy(forcedMinMinutes = it) }
                                NumberStepper(
                                    label = "حداکثر دقیقه‌ی انتخاب",
                                    value = r.forcedMaxMinutes,
                                    min = r.forcedMinMinutes,
                                    max = 480,
                                    step = 5
                                ) { r = r.copy(forcedMaxMinutes = it) }
                            }
                            ReactionKind.ETERNAL -> {
                                Text(
                                    "تا وقتی یکی از محرک‌های قفل ابدی (تماس، ری‌استارت، رمز، معما یا تأیید AI) رخ ندهد باز نمی‌شود.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(r) }) { Text("ذخیره") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("بستن") } }
    )

    if (showTriggerPicker) {
        AlertDialog(
            onDismissRequest = { showTriggerPicker = false },
            title = { Text("نوع محرک") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    TriggerKind.entries.forEach { k ->
                        RadioRow(
                            title = k.label,
                            selected = r.trigger == k,
                            onClick = {
                                r = r.copy(trigger = k)
                                showTriggerPicker = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showTriggerPicker = false }) { Text("بستن") }
            }
        )
    }
    if (showReactionPicker) {
        AlertDialog(
            onDismissRequest = { showReactionPicker = false },
            title = { Text("نوع واکنش") },
            text = {
                Column {
                    ReactionKind.entries.forEach { k ->
                        RadioRow(
                            title = k.label,
                            selected = r.reaction == k,
                            onClick = {
                                r = r.copy(reaction = k)
                                showReactionPicker = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showReactionPicker = false }) { Text("بستن") }
            }
        )
    }
    if (showAppsPicker) {
        AppsMultiSelectDialog(
            selected = r.apps.toSet(),
            onDismiss = { showAppsPicker = false },
            onSave = { set ->
                r = r.copy(apps = set.toMutableList())
                showAppsPicker = false
            }
        )
    }
}

@Composable
fun AppsMultiSelectDialog(
    selected: Set<String>,
    onDismiss: () -> Unit,
    onSave: (Set<String>) -> Unit
) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<AppList.AppInfo>>(emptyList()) }
    var sel by remember { mutableStateOf(selected.toMutableSet()) }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            apps = AppList.ensureLoaded(context)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("برنامه‌های محرک (${sel.size.toFa()})") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text("جستجو…") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                val filtered = apps.filter {
                    search.isBlank() || it.label.contains(search) || it.pkg.contains(search)
                }
                filtered.take(300).forEach { app ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        if (app.icon != null) {
                            Image(
                                bitmap = app.icon.asImageBitmap(),
                                contentDescription = app.label,
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                            )
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                            Text(app.label, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                app.pkg,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        androidx.compose.material3.Checkbox(
                            checked = app.pkg in sel,
                            onCheckedChange = { on ->
                                if (on) sel.add(app.pkg) else sel.remove(app.pkg)
                            }
                        )
                    }
                }
                if (filtered.isEmpty()) {
                    Text("در حال بارگذاری فهرست برنامه‌ها…", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(sel.toSet()) }) { Text("تأیید (${sel.size.toFa()})") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("بستن") } }
    )
}
