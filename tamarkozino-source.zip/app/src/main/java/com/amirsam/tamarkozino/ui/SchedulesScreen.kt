package com.amirsam.tamarkozino.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.core.Schedule
import com.amirsam.tamarkozino.core.ScheduleKind
import com.amirsam.tamarkozino.util.formatHm
import com.amirsam.tamarkozino.util.toFa
import com.amirsam.tamarkozino.util.toTimeLabel

/**
 * برنامه‌های روزانه: قفل بازه‌ای، سؤال، قفل اجباری، انتخاب زمان اجباری
 */
@Composable
fun SchedulesScreen(nav: NavController) {
    var schedules by remember { mutableStateOf(Prefs.schedules()) }
    var editing by remember { mutableStateOf<Schedule?>(null) }

    fun save() {
        Prefs.setSchedules(schedules)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "زمان‌بندی روزانه ⏰",
                fontFamily = com.amirsam.tamarkozino.ui.theme.lalezarFont,
                fontSize = 30.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = { nav.popBackStack() }) { Text("بازگشت") }
        }
        Text(
            "برنامه‌های هر روز: قفل بازه‌ای (مثلاً ۱۵ تا ۱۶)، سؤال بله/خیر در ساعت مشخص، قفل اجباری، یا صفحه‌ی انتخاب زمان اجباری با حداقل/حداکثر.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(14.dp))

        if (schedules.isEmpty()) {
            Text(
                "هنوز برنامه‌ای روزانه‌ای نساخته‌ای — با دکمه‌ی زیر یکی بساز ☀️",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        schedules.forEach { s ->
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            s.kind.label,
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        Switch(
                            checked = s.enabled,
                            onCheckedChange = { on ->
                                schedules = schedules.map {
                                    if (it.id == s.id) it.copy(enabled = on) else it
                                }.toMutableList()
                                save()
                            }
                        )
                    }
                    Text(scheduleSummary(s), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            editing = s
                        }) { Text("ویرایش ✏️") }
                        OutlinedButton(onClick = {
                            schedules = (schedules.filter { it.id != s.id }).toMutableList()
                            save()
                        }) { Text("حذف 🗑") }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        Button(
            onClick = { editing = Schedule() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("افزودن برنامه‌ی روزانه ➕") }

        Spacer(Modifier.height(10.dp))
        SignatureFooter()
    }

    editing?.let { s ->
        ScheduleEditorDialog(
            initial = s,
            onDismiss = { editing = null },
            onSave = { saved ->
                schedules = (schedules.filter { it.id != saved.id } + saved).toMutableList()
                save()
                editing = null
            }
        )
    }
}

fun scheduleSummary(s: Schedule): String {
    return when (s.kind) {
        ScheduleKind.WINDOW_LOCK ->
            "هر روز از ${s.windowStart.toTimeLabel()} تا ${s.windowEnd.toTimeLabel()} قفل است"
        ScheduleKind.ASK_AT_TIME ->
            "هر روز ساعت ${s.timeMinute.toTimeLabel()} می‌پرسیم؛ اگر بگویی آره، برای ${s.askDurationMinutes.formatHm()} قفل می‌شود"
        ScheduleKind.FORCED_LOCK_AT_TIME ->
            "هر روز ساعت ${s.timeMinute.toTimeLabel()} گوشی برای ${s.durationMinutes.formatHm()} قفل می‌شود (اجباری)"
        ScheduleKind.FORCED_CHOOSE_AT_TIME ->
            "هر روز ساعت ${s.timeMinute.toTimeLabel()} صفحه‌ی انتخاب زمان اجباری می‌آید (بین ${s.forcedMinMinutes.formatHm()} و ${s.forcedMaxMinutes.formatHm()})"
    }
}

@Composable
private fun ScheduleEditorDialog(
    initial: Schedule,
    onDismiss: () -> Unit,
    onSave: (Schedule) -> Unit
) {
    var s by remember { mutableStateOf(initial) }
    var showKindPicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("برنامه‌ی روزانه ⏰") },
        text = {
            Column {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Text(s.kind.label, style = MaterialTheme.typography.titleSmall)
                        Text(scheduleSummary(s), style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        OutlinedButton(onClick = { showKindPicker = true }) {
                            Text("تغییر نوع")
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                if (s.kind == ScheduleKind.WINDOW_LOCK) {
                    TimeSteppers("شروع بازه", s.windowStart) { s = s.copy(windowStart = it) }
                    TimeSteppers("پایان بازه", s.windowEnd) { s = s.copy(windowEnd = it) }
                } else {
                    TimeSteppers("ساعتِ اجرا", s.timeMinute) { s = s.copy(timeMinute = it) }
                }

                when (s.kind) {
                    ScheduleKind.ASK_AT_TIME -> {
                        NumberStepper(
                            label = "مدت قفل اگر «آره» گفت",
                            value = s.askDurationMinutes,
                            min = 5,
                            max = 480,
                            step = 5
                        ) { s = s.copy(askDurationMinutes = it) }
                    }
                    ScheduleKind.FORCED_LOCK_AT_TIME -> {
                        NumberStepper(
                            label = "مدت قفل (دقیقه)",
                            value = s.durationMinutes,
                            min = 5,
                            max = 480,
                            step = 5
                        ) { s = s.copy(durationMinutes = it) }
                    }
                    ScheduleKind.FORCED_CHOOSE_AT_TIME -> {
                        NumberStepper(
                            label = "حداقل دقیقه‌ی انتخاب",
                            value = s.forcedMinMinutes,
                            min = 5,
                            max = 240,
                            step = 5
                        ) { s = s.copy(forcedMinMinutes = it) }
                        NumberStepper(
                            label = "حداکثر دقیقه‌ی انتخاب",
                            value = s.forcedMaxMinutes,
                            min = s.forcedMinMinutes,
                            max = 480,
                            step = 5
                        ) { s = s.copy(forcedMaxMinutes = it) }
                    }
                    ScheduleKind.WINDOW_LOCK -> {
                        // بازه‌ها بالا تنظیم شدند
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(s) }) { Text("ذخیره") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("بستن") } }
    )

    if (showKindPicker) {
        AlertDialog(
            onDismissRequest = { showKindPicker = false },
            title = { Text("نوع برنامه") },
            text = {
                Column {
                    ScheduleKind.entries.forEach { k ->
                        RadioRow(
                            title = k.label,
                            selected = s.kind == k,
                            onClick = {
                                s = s.copy(kind = k)
                                showKindPicker = false
                            }
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showKindPicker = false }) { Text("بستن") }
            }
        )
    }
}

/** ویرایش ساعت و دقیقه (minuteOfDay) */
@Composable
fun TimeSteppers(label: String, minuteOfDay: Int, onChange: (Int) -> Unit) {
    NumberStepper(
        label = "$label — ساعت",
        value = minuteOfDay / 60,
        min = 0,
        max = 23
    ) { h -> onChange(h * 60 + minuteOfDay % 60) }
    NumberStepper(
        label = "$label — دقیقه",
        value = minuteOfDay % 60,
        min = 0,
        max = 59,
        step = 5
    ) { m -> onChange((minuteOfDay / 60) * 60 + m) }
}
