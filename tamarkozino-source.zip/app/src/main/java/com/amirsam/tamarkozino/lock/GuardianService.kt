package com.amirsam.tamarkozino.lock

import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.app.ServiceCompat
import com.amirsam.tamarkozino.MainActivity
import com.amirsam.tamarkozino.R
import com.amirsam.tamarkozino.core.AppList
import com.amirsam.tamarkozino.core.LockManager
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.core.RulesEngine
import com.amirsam.tamarkozino.core.UsageTracker
import com.amirsam.tamarkozino.util.formatCountdown
import com.amirsam.tamarkozino.util.nowMs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * سرویس نگهبان تمرکزینو — همیشه روشن:
 * - هنگام قفل: پوشش‌دهی سریع صفحه‌ی قفل روی برنامه‌های غیرمجاز
 * - همیشه: پایش رخدادهای روشن/خاموش صفحه، ارزیابی قوانین و برنامه‌های روزانه
 */
class GuardianService : android.app.Service() {

    companion object {
        const val CHANNEL_GUARDIAN = "guardian"
        const val CHANNEL_FOCUS = "focus"
        const val NOTIF_GUARDIAN_ID = 1001
        const val EVENT_NOTIF_ID = 2001
        const val ACTION_COVER = "com.amirsam.tamarkozino.COVER"

        @Volatile
        var instance: GuardianService? = null

        fun ensureRunning(context: Context) {
            if (instance != null) return
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, GuardianService::class.java)
                )
            } catch (e: Exception) {
                // در شرایط محدودیت پس‌زمینه نادیده گرفته می‌شود
            }
        }

        fun requestCover(context: Context) {
            val svc = instance
            if (svc != null) {
                svc.doCover()
            } else {
                try {
                    ContextCompat.startForegroundService(
                        context,
                        Intent(context, GuardianService::class.java).setAction(ACTION_COVER)
                    )
                } catch (e: Exception) {
                    // نادیده گرفته می‌شود
                }
            }
        }

        /** اعلان رخداد (شروع/پایان قفل) */
        fun notifyEvent(context: Context, title: String, text: String) {
            // اگر کاربر «اعلان‌ها در زمان قفل» را خاموش کرده، در زمان قفل اعلان نمی‌فرستیم
            if (Prefs.lockActive && !Prefs.notificationsInLock) return
            try {
                val builder = if (Build.VERSION.SDK_INT >= 26) {
                    Notification.Builder(context, CHANNEL_FOCUS)
                } else {
                    @Suppress("DEPRECATION")
                    Notification.Builder(context)
                }
                val notif = builder
                    .setSmallIcon(R.drawable.ic_stat_lock)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setAutoCancel(true)
                    .build()
                NotificationManagerCompat.from(context).notify(EVENT_NOTIF_ID, notif)
            } catch (e: Exception) {
                // بدون مجوز اعلان یا هر خطای دیگر
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var screenOn = false

    private var lastCoverAt = 0L
    private var tickCounter = 0

    private val masterTick: Runnable = object : Runnable {
        override fun run() {
            try {
                tickCounter++
                val locked = LockManager.isLocked()

                // پوشش‌دهی سریع در حالت قفل
                if (locked && screenOn) {
                    maybeCover()
                }

                // هر حدود ۱.۵ ثانیه: بررسی پایان قفل و اعمال مجدد محدودیت‌ها
                if (tickCounter % 5 == 0 && locked) {
                    LockManager.maybeEndTimed(this@GuardianService)
                    LockManager.applyEnforcements(this@GuardianService)
                }

                // هر حدود ۶ ثانیه: به‌روزرسانی متن اعلان نگهبان
                if (tickCounter % 20 == 0 && locked) {
                    updateGuardianNotification()
                }

                // هر حدود ۳۰ ثانیه: ارزیابی قوانین و برنامه‌های روزانه
                if (tickCounter % 100 == 0) {
                    scope.launch {
                        try {
                            UsageTracker.maybeDailyReset()
                            RulesEngine.evaluateRules(this@GuardianService)
                            RulesEngine.evaluateSchedules(this@GuardianService)
                        } catch (e: Exception) {
                            // نادیده گرفته می‌شود
                        }
                    }
                }

                handler.postDelayed(this, 300L)
            } catch (e: Exception) {
                handler.postDelayed(this, 300L)
            }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON -> onScreenOn()
                Intent.ACTION_SCREEN_OFF -> onScreenOff()
            }
        }
    }

    override fun onCreate() {
        instance = this
        super.onCreate()
        startAsForeground()
        registerScreenReceivers()
        handler.post(masterTick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        instance = this
        if (intent?.action == ACTION_COVER) {
            doCover()
        }
        // اگر حلقه‌ای متوقف شده باشد دوباره راه می‌افتد
        handler.removeCallbacks(masterTick)
        handler.post(masterTick)
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(masterTick)
        scope.cancel()
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) {
            // نادیده گرفته می‌شود
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ---------------- راه‌اندازی ----------------

    private fun startAsForeground() {
        try {
            val notif = buildGuardianNotification()
            val type = if (Build.VERSION.SDK_INT >= 34) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else 0
            ServiceCompat.startForeground(this, NOTIF_GUARDIAN_ID, notif, type)
        } catch (e: Exception) {
            // نادیده گرفته می‌شود
        }
    }

    private fun buildGuardianNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this, 0,
            if (LockManager.isLocked()) {
                Intent(this, LockScreenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            } else {
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val remaining = LockManager.remainingMs()
        val text = when {
            !LockManager.isLocked() -> "در حال پایش قوانین و برنامه‌های روزانه…"
            remaining == null -> "قفل ابدی فعال است ♾"
            else -> "باقی‌مانده: ${remaining.formatCountdown()}"
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_GUARDIAN)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(R.drawable.ic_stat_lock)
            .setContentTitle("تمرکزینو در حال نگهبانی است 🛡")
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateGuardianNotification() {
        try {
            val nm = NotificationManagerCompat.from(this)
            nm.notify(NOTIF_GUARDIAN_ID, buildGuardianNotification())
        } catch (e: Exception) {
            // نادیده گرفته می‌شود
        }
    }

    private fun registerScreenReceivers() {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        try {
            registerReceiver(screenReceiver, filter)
        } catch (e: Exception) {
            // نادیده گرفته می‌شود
        }
    }

    // ---------------- ردیابی صفحه ----------------

    private fun onScreenOn() {
        screenOn = true
        val now = nowMs()
        Prefs.screenOpenSince = now
        Prefs.addUnlockTime(now)
        // اگر گوشی در حالت قفل روشن شد، فوراً صفحه‌ی قفل را نشان بده
        if (LockManager.isLocked()) {
            LockScreenActivity.show(this)
        }
    }

    private fun onScreenOff() {
        screenOn = false
        val since = Prefs.screenOpenSince
        if (since > 0) {
            Prefs.addScreenInterval(since, nowMs())
            Prefs.screenOpenSince = 0L
        }
    }

    // ---------------- پوشش‌دهی ----------------

    private fun maybeCover() {
        if (nowMs() - lastCoverAt < 250) return
        if (!shouldCover()) return
        lastCoverAt = nowMs()
        LockScreenActivity.show(this)
    }

    private fun doCover() {
        if (!LockManager.isLocked()) return
        if (nowMs() - lastCoverAt < 250) return
        lastCoverAt = nowMs()
        LockScreenActivity.show(this)
    }

    private fun shouldCover(): Boolean {
        if (!LockManager.isLocked()) return false
        val pkg = LockAccessibilityService.lastForegroundPackage ?: return false
        val cls = LockAccessibilityService.lastForegroundClass ?: ""
        val ourPkg = packageName

        if (pkg == ourPkg) {
            // صفحه‌ی اصلی خودمان در حالت قفل باز شده → بپوشان
            return cls == MainActivity::class.java.name
        }
        if (pkg == "com.android.systemui" || pkg == "android") return false
        if (pkg in Prefs.allowedApps()) return false
        val smsOk = Prefs.smsFromNotification && pkg == AppList.defaultSmsPackage(this)
        return !smsOk
    }
}
