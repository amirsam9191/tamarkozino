package com.amirsam.tamarkozino

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.amirsam.tamarkozino.lock.GuardianService
import com.amirsam.tamarkozino.ui.AllowedAppsScreen
import com.amirsam.tamarkozino.ui.HomeScreen
import com.amirsam.tamarkozino.ui.OnboardingScreen
import com.amirsam.tamarkozino.ui.RulesScreen
import com.amirsam.tamarkozino.ui.SchedulesScreen
import com.amirsam.tamarkozino.ui.SettingsScreen
import com.amirsam.tamarkozino.ui.theme.TamarkozinoTheme

class MainActivity : ComponentActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TamarkozinoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppRoot()
                }
            }
        }

        if (Build.VERSION.SDK_INT >= 33) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        // سرویس نگهبان همیشه در حال کار است
        GuardianService.ensureRunning(this)
    }
}

@androidx.compose.runtime.Composable
fun AppRoot() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("onboarding") { OnboardingScreen(nav) }
        composable("allowed") { AllowedAppsScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
        composable("schedules") { SchedulesScreen(nav) }
        composable("rules") { RulesScreen(nav) }
    }
}
