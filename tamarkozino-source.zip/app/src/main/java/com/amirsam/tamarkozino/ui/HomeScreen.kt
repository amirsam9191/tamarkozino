package com.amirsam.tamarkozino.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.amirsam.tamarkozino.core.AppList
import com.amirsam.tamarkozino.core.LockManager
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.lock.LockAccessibilityService
import com.amirsam.tamarkozino.lock.LockScreenActivity
import com.amirsam.tamarkozino.ui.theme.Blue600
import com.amirsam.tamarkozino.ui.theme.lalezarFont
import com.amirsam.tamarkozino.util.formatCountdown
import com.amirsam.tamarkozino.util.formatHm
import com.amirsam.tamarkozino.util.nowMs
import com.amirsam.tamarkozino.util.toFa
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * صفحه‌ی اصلی: انتخاب مدت تمرکز و دکمه‌ی شروع
 */
@Composable
fun HomeScreen(nav: NavController) {
    val context = LocalContext.current
    var minutes by remember { mutableStateOf(80) }
    var now by remember { mutableStateOf(nowMs()) }
    var allowedIcons by remember { mutableStateOf<List<AppList.AppInfo>>(emptyList()) }
    var allowedCount by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    fun refreshAllowed() {
        scope.launch(Dispatchers.IO) {
            val all = AppList.ensureLoaded(context)
            val set = Prefs.allowedApps()
            withContext(Dispatchers.Main) {
                allowedCount = set.size
                allowedIcons = all.filter { it.pkg in set }.take(6)
            }
        }
    }

    LaunchedEffect(Unit) {
        refreshAllowed()
        while (isActive) {
            delay(1000)
            now = nowMs()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        // هدر
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "تمرکزینو",
                    fontFamily = lalezarFont,
                    fontSize = 38.sp,
                    color = Blue600
                )
                Text(
                    "دوستِ تمرکز تو 🧘",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { nav.navigate("settings") }) {
                Icon(
                    Icons.Default.Settings,
                    contentDescription = "تنظیمات",
                    tint = Blue600
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        // وضعیت قفل فعال
        if (Prefs.lockActive) {
            val remaining = LockManager.remainingMs()
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        if (Prefs.lockEternal) "قفل ابدی فعال است ♾"
                        else "قفل فعال است 🧘 — باقی‌مانده: ${(remaining ?: 0L).formatCountdown()}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { LockScreenActivity.show(context) }) {
                        Text("مشاهده صفحه قفل")
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        // بنر دسترسی‌ها در صورت نبود
        val needSetup =
            !android.provider.Settings.canDrawOverlays(context) || !LockAccessibilityService.isRunning()
        if (needSetup) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                shape = RoundedCornerShape(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "برای قفل واقعی، چند دسترسی لازمه 🔑",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            "نمایش روی دیگر اپ‌ها و سرویس دسترسی‌پذیری فعالی نیست.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                    Button(onClick = { nav.navigate("onboarding") }) { Text("فعال‌سازی") }
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        // کارت انتخاب زمان
        SectionCard(title = "مدت تمرکز خودت رو انتخاب کن ⏱") {
            // پیش‌تنظیم‌های سریع
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(
                    "۲۵ دقیقه" to 25,
                    "۴۵ دقیقه" to 45,
                    "۱ ساعت" to 60,
                    "۱:۲۰ ساعت" to 80,
                    "۲ ساعت" to 120
                ).forEach { (label, value) ->
                    val selected = minutes == value
                    Surface(
                        color = if (selected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { minutes = value }
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) {
                                androidx.compose.ui.graphics.Color.White
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            NumberStepper(
                label = "ساعت",
                value = minutes / 60,
                min = 0,
                max = 12
            ) { h -> minutes = (h * 60 + minutes % 60).coerceAtLeast(5) }
            NumberStepper(
                label = "دقیقه",
                value = minutes % 60,
                min = 0,
                max = 59,
                step = 5
            ) { m -> minutes = ((minutes / 60) * 60 + m).coerceAtLeast(5) }

            Spacer(Modifier.height(8.dp))
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    "قفل برای ${minutes.formatHm()} 🧘",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp)
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        // دکمه‌ی شروع
        GradientButton(
            text = "شروع تمرکز 🚀",
            onClick = {
                LockManager.startTimedLock(
                    context,
                    minutes.coerceAtLeast(5),
                    "شروع دستی 🚀"
                )
            }
        )

        Spacer(Modifier.height(14.dp))

        // برنامه‌های مجاز
        SectionCard(title = "برنامه‌های مجاز در زمان قفل 📲") {
            Text(
                "${allowedCount.toFa()} برنامه مجاز — هنگام قفل فقط همین‌ها باز می‌شوند و آیکون‌شان در صفحه قفل نمایش داده می‌شود.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            if (allowedIcons.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    allowedIcons.forEach { info ->
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            if (info.icon != null) {
                                Image(
                                    bitmap = info.icon.asImageBitmap(),
                                    contentDescription = info.label,
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Button(onClick = { nav.navigate("allowed") }) {
                Text("مدیریت برنامه‌های مجاز")
            }
        }

        Spacer(Modifier.height(14.dp))

        // میان‌برها
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NavCard("قوانین هوشمند ⚖️", Modifier.weight(1f)) { nav.navigate("rules") }
            NavCard("زمان‌بندی روزانه ⏰", Modifier.weight(1f)) { nav.navigate("schedules") }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            NavCard("تنظیمات ⚙️", Modifier.weight(1f)) { nav.navigate("settings") }
            NavCard("دسترسی‌ها و مجوزها 🔑", Modifier.weight(1f)) { nav.navigate("onboarding") }
        }

        Spacer(Modifier.height(8.dp))
        SignatureFooter()
    }
}

@Composable
private fun NavCard(title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant,
                RoundedCornerShape(20.dp)
            )
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
