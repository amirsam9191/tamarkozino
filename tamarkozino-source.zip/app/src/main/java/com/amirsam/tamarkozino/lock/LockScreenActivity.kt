package com.amirsam.tamarkozino.lock

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.amirsam.tamarkozino.ai.AiChatActivity
import com.amirsam.tamarkozino.core.AppList
import com.amirsam.tamarkozino.core.LockManager
import com.amirsam.tamarkozino.core.Motivation
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.ui.SignatureFooter
import com.amirsam.tamarkozino.ui.theme.Blue600
import com.amirsam.tamarkozino.ui.theme.BlueLight
import com.amirsam.tamarkozino.ui.theme.TamarkozinoTheme
import com.amirsam.tamarkozino.ui.theme.lalezarFont
import com.amirsam.tamarkozino.util.formatCountdown
import com.amirsam.tamarkozino.util.normalizeAnswer
import com.amirsam.tamarkozino.util.nowMs
import com.amirsam.tamarkozino.util.sha256Hex
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * صفحه‌ی قفل تمرکز — مدرن، روی همه‌ی برنامه‌ها؛
 * Home و Back بی‌اثر، فقط برنامه‌های مجاز از ریسنت‌ها در دسترس‌اند.
 */
class LockScreenActivity : ComponentActivity() {

    companion object {
        fun show(context: Context) {
            val intent = Intent(context, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(
                    intent,
                    ActivityOptions.makeCustomAnimation(context, 0, 0).toBundle()
                )
            } catch (e: Exception) {
                // نادیده گرفته می‌شود
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        windowSetup()
        if (Prefs.lockPinning) {
            try {
                startLockTask()
            } catch (e: Exception) {
                // نادیده گرفته می‌شود
            }
        }
        setContent {
            TamarkozinoTheme {
                LockScreenContent(
                    onExit = { finish() },
                    onUnlock = { reason -> LockManager.unlock(this, reason) }
                )
            }
        }
    }

    private fun windowSetup() {
        if (Build.VERSION.SDK_INT >= 27) {
            window.setShowWhenLocked(true)
            window.setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // دکمه‌ی برگشت در صفحه‌ی قفل بی‌اثر است
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
fun LockScreenContent(
    onExit: () -> Unit,
    onUnlock: (String) -> Unit
) {
    val context = LocalContext.current
    var now by remember { mutableStateOf(nowMs()) }
    var showPin by remember { mutableStateOf(false) }
    var showRiddle by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (isActive) {
            delay(1000)
            now = nowMs()
        }
    }

    BackHandler {
        if (Prefs.backMotivate) {
            Toast.makeText(
                context,
                "برگشتی؟ 😏 تمرکز هنوز ادامه داره…",
                Toast.LENGTH_SHORT
            ).show()
        }
        // در هر حالت، بازگشت بی‌اثر است
    }

    val locked = Prefs.lockActive
    val eternal = Prefs.lockEternal
    val remaining = if (eternal) null else (Prefs.lockEndMs - now).coerceAtLeast(0L)
    val total = if (Prefs.lockTotalMs > 0) Prefs.lockTotalMs else 1L

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // هاله‌های نرم آبی پس‌زمینه
        Box(
            modifier = Modifier
                .offset(x = (-60).dp, y = (-80).dp)
                .size(240.dp)
                .background(
                    Brush.radialGradient(listOf(Color(0x221554C0), Color.Transparent)),
                    CircleShape
                )
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .offset(x = 40.dp, y = 50.dp)
                .size(260.dp)
                .background(
                    Brush.radialGradient(listOf(Color(0x1E5B8DEF), Color.Transparent)),
                    CircleShape
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!locked) {
                CompletionView(reason = Prefs.lastUnlockReason, onExit = onExit)
            } else {
                // چیپ دلیل قفل
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(50)
                ) {
                    Text(
                        "  ${Prefs.lockReason.ifBlank { "تمرکز" }}  ",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }

                Spacer(Modifier.height(18.dp))

                // تایمر یا نماد ابدی
                if (eternal) {
                    Text("♾️", fontSize = 68.sp)
                    Text(
                        "قفل ابدی فعال است",
                        fontFamily = lalezarFont,
                        fontSize = 34.sp,
                        color = Blue600
                    )
                } else {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(220.dp)
                    ) {
                        RingProgress(fraction = (remaining ?: 0L).toFloat() / total.toFloat())
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                (remaining ?: 0L).formatCountdown(),
                                fontFamily = lalezarFont,
                                fontSize = 44.sp,
                                color = Blue600
                            )
                            Text(
                                "باقی‌مانده از تمرکز",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                Text(
                    "شما در حالت تمرکز هستید 🧘",
                    fontFamily = lalezarFont,
                    fontSize = 28.sp,
                    color = Blue600,
                    textAlign = TextAlign.Center
                )
                Text(
                    "لطفاً تمرکز کنید ✨",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(18.dp))

                // چرخاننده جمله‌های انگیزشی
                QuoteRotator()

                Spacer(Modifier.height(18.dp))

                AllowedAppsBlock()

                // روش‌های باز کردن قفل ابدی
                if (eternal) {
                    Spacer(Modifier.height(14.dp))
                    EternalUnlockBlock(
                        onPin = { showPin = true },
                        onRiddle = { showRiddle = true },
                        onAi = {
                            try {
                                context.startActivity(
                                    Intent(
                                        context,
                                        AiChatActivity::class.java
                                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (e: Exception) {
                                // نادیده گرفته می‌شود
                            }
                        }
                    )
                }

                Spacer(Modifier.height(10.dp))
                SignatureFooter()
            }
        }
    }

    if (showPin) {
        PinDialog(
            onDismiss = { showPin = false },
            onSuccess = {
                showPin = false
                onUnlock("رمز درست بود 🔢")
            }
        )
    }
    if (showRiddle) {
        RiddleDialog(
            onDismiss = { showRiddle = false },
            onSuccess = {
                showRiddle = false
                onUnlock("معما حل شد 🧩")
            }
        )
    }
}

@Composable
private fun CompletionView(reason: String, onExit: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(5000)
        onExit()
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("🎉", fontSize = 64.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "تمرکز کامل شد!",
            fontFamily = lalezarFont,
            fontSize = 32.sp,
            color = Blue600
        )
        Text(
            reason,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(18.dp))
        Button(onClick = onExit) { Text("بازگشت به گوشی 🚀") }
    }
}

/** حلقه‌ی پیشرفت زمان تمرکز */
@Composable
private fun RingProgress(fraction: Float, modifier: Modifier = Modifier) {
    val trackColor = Color(0xFFE4EBF8)
    val brush = Brush.sweepGradient(listOf(Blue600, BlueLight, Blue600))
    Canvas(modifier = modifier.size(220.dp)) {
        val stroke = 12.dp.toPx()
        val inset = stroke / 2
        val arcSize = Size(size.width - stroke, size.height - stroke)
        val topLeft = Offset(inset, inset)
        drawArc(
            color = trackColor,
            startAngle = -90f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )
        val f = fraction.coerceIn(0f, 1f)
        if (f > 0.005f) {
            drawArc(
                brush = brush,
                startAngle = -90f,
                sweepAngle = 360f * f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
    }
}

/** چرخاننده‌ی جمله‌های انگیزشی */
@Composable
private fun QuoteRotator() {
    var quote by remember { mutableStateOf(Motivation.next()) }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(8000)
            quote = Motivation.next()
        }
    }
    AnimatedContent(
        targetState = quote,
        transitionSpec = {
            fadeIn(tween(700)) togetherWith fadeOut(tween(700))
        }
    ) { q ->
        Text(
            "❝ $q ❞",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** ردیف برنامه‌های مجاز */
@Composable
private fun AllowedAppsBlock() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<AppList.AppInfo>>(emptyList()) }
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val set = Prefs.allowedApps()
            apps = AppList.ensureLoaded(context).filter { it.pkg in set }
        }
    }

    Text(
        "برنامه‌های مجاز شما 📲",
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary
    )
    Spacer(Modifier.height(8.dp))

    if (apps.isEmpty()) {
        Text(
            "هنوز برنامه‌ی مجازی انتخاب نشده؛ قبل از قفل بعدی از تنظیمات اضافه کن 🔧",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    } else {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(apps) { info ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(78.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .clickable {
                            try {
                                val launch = context.packageManager
                                    .getLaunchIntentForPackage(info.pkg)
                                if (launch != null) context.startActivity(launch)
                            } catch (e: Exception) {
                                // نادیده گرفته می‌شود
                            }
                        }
                        .padding(6.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        if (info.icon != null) {
                            Image(
                                bitmap = info.icon.asImageBitmap(),
                                contentDescription = info.label,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                            )
                        }
                    }
                    Text(
                        info.label,
                        fontSize = 11.sp,
                        maxLines = 1,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

/** روش‌های باز کردن قفل ابدی */
@Composable
private fun EternalUnlockBlock(onPin: () -> Unit, onRiddle: () -> Unit, onAi: () -> Unit) {
    val cfg = Prefs.eternalConfig()
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "راه‌های باز شدن قفل ♾",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (cfg.pinEnabled) {
                FilledTonalButton(onClick = onPin) { Text("🔢 رمز") }
            }
            if (cfg.riddleEnabled) {
                FilledTonalButton(onClick = onRiddle) { Text("🧩 معما") }
            }
            if (cfg.aiUnlock) {
                FilledTonalButton(onClick = onAi) { Text("🤖 هوش مصنوعی") }
            }
        }
        val autos = mutableListOf<String>()
        if (cfg.callUnlock) autos.add("📞 زنگ تماس ورودی")
        if (cfg.rebootUnlock) autos.add("♻️ خاموش/روشن شدن گوشی")
        if (autos.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text(
                "این‌ها هم به‌محض رخ دادن خودکار قفل را باز می‌کنند: ${autos.joinToString(" • ")}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }
        if (!cfg.pinEnabled && !cfg.riddleEnabled && !cfg.aiUnlock && autos.isEmpty()) {
            Text(
                "هیچ راهِ بازکردنی فعال نیست! از تنظیمات یک روش را فعال کن ⚠️",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun PinDialog(onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var value by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("رمز باز شدن 🔢") },
        text = {
            Column {
                Text("رمز قفل ابدی را وارد کن")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it; error = false },
                    singleLine = true,
                    isError = error
                )
                if (error) {
                    Text(
                        "رمز درست نیست 🙈",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (sha256Hex(value) == Prefs.eternalConfig().pinHash) {
                        onSuccess()
                    } else {
                        error = true
                    }
                }
            ) { Text("تأیید") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("بستن") } }
    )
}

@Composable
private fun RiddleDialog(onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var value by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("معمای خودت 🧩") },
        text = {
            Column {
                Text(Prefs.eternalConfig().riddleQuestion.ifBlank { "معمایی تنظیم نشده است" })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = value,
                    onValueChange = { value = it; error = false },
                    singleLine = true,
                    isError = error
                )
                if (error) {
                    Text(
                        "پاسخ درست نیست 🤔",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cfg = Prefs.eternalConfig()
                    if (normalizeAnswer(value) == normalizeAnswer(cfg.riddleAnswer)) {
                        onSuccess()
                    } else {
                        error = true
                    }
                }
            ) { Text("تأیید") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("بستن") } }
    )
}
