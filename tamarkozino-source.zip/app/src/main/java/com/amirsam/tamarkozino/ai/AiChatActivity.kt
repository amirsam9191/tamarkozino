package com.amirsam.tamarkozino.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.amirsam.tamarkozino.core.LockManager
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.ui.theme.Blue600
import com.amirsam.tamarkozino.ui.theme.TamarkozinoTheme
import com.amirsam.tamarkozino.ui.theme.lalezarFont
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/**
 * گفتگو با نگهبان هوش مصنوعی برای باز کردن قفل ابدی
 */
class AiChatActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            window.setShowWhenLocked(true)
            window.setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        setContent {
            TamarkozinoTheme {
                AiChatScreen(
                    onApproved = {
                        LockManager.unlock(this, "تأیید هوش مصنوعی 🤖✅")
                        finish()
                    }
                )
            }
        }
    }
}

private data class UiMsg(val fromUser: Boolean, val text: String)

@Composable
fun AiChatScreen(onApproved: () -> Unit) {
    val context = LocalContext.current
    val cfg = remember { Prefs.aiConfig() }
    var history by remember { mutableStateOf(listOf<AiClient.ChatMessage>()) }
    var ui by remember { mutableStateOf(listOf<UiMsg>()) }
    var input by remember { mutableStateOf("") }
    var pendingImageB64 by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var approved by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        uri?.let {
            scope.launch(Dispatchers.IO) {
                val b64 = decodeToBase64Jpeg(context, it)
                if (b64 != null) {
                    withContext(Dispatchers.Main) { pendingImageB64 = b64 }
                } else {
                    withContext(Dispatchers.Main) {
                        ui = ui + UiMsg(false, "⚠️ تصویر خوانده نشد؛ دوباره امتحان کن.")
                    }
                }
            }
        }
    }

    LaunchedEffect(ui.size) {
        if (ui.isNotEmpty()) listState.animateScrollToItem(ui.size - 1)
    }

    fun send() {
        if (busy) return
        val text = input.trim()
        val image = pendingImageB64
        if (text.isEmpty() && image == null) return
        input = ""
        pendingImageB64 = null
        ui = ui + UiMsg(true, text.ifBlank { "[تصویر ارسال شد] 📷" })
        history = history + AiClient.ChatMessage("user", text, image)
        busy = true
        scope.launch(Dispatchers.IO) {
            try {
                val reply = AiClient.chatBlocking(cfg, history)
                withContext(Dispatchers.Main) {
                    history = history + AiClient.ChatMessage("assistant", reply)
                    ui = ui + UiMsg(false, reply)
                    busy = false
                    if (AiClient.isApproved(reply)) approved = true
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    ui = ui + UiMsg(false, "⚠️ ${e.message ?: "خطای نامشخص"}")
                    busy = false
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        if (approved) {
            ApprovedView(onDone = onApproved)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 40.dp, start = 16.dp, end = 16.dp, bottom = 16.dp)
            ) {
                // هدر
                Text(
                    "گفتگو با نگهبان هوشمند 🤖",
                    fontFamily = lalezarFont,
                    fontSize = 26.sp,
                    color = Blue600
                )
                Text(
                    "سخت‌گیری: ${cfg.strictness.label} — مدل: ${cfg.model}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (ui.isEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text(
                                "برای باز شدن قفل، به نگهبان نشان بده که کارت انجام شده 📸💬",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "شرطی که خودت تعریف کردی: «${cfg.taskDescription}»",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(ui) { m ->
                        Bubble(m)
                    }
                    if (busy) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    "نگهبان دارد فکر می‌کند…",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (pendingImageB64 != null) {
                    Spacer(Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("📎 تصویر آماده ارسال است", style = MaterialTheme.typography.bodySmall)
                        FilledTonalButton(onClick = { pendingImageB64 = null }) {
                            Text("حذف")
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text("بنویس…") },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 56.dp),
                        maxLines = 3
                    )
                    FilledTonalButton(
                        onClick = {
                            picker.launch(
                                PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        modifier = Modifier.height(56.dp)
                    ) { Text("📷") }

                    Button(
                        onClick = { send() },
                        modifier = Modifier.height(56.dp)
                    ) { Text("ارسال") }
                }
            }
        }
    }
}

@Composable
private fun Bubble(m: UiMsg) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.fromUser) Arrangement.Start else Arrangement.End
    ) {
        Surface(
            color = if (m.fromUser) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
            shape = RoundedCornerShape(
                topStart = 18.dp, topEnd = 18.dp,
                bottomStart = if (m.fromUser) 18.dp else 4.dp,
                bottomEnd = if (m.fromUser) 4.dp else 18.dp
            )
        ) {
            Text(
                m.text,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun ApprovedView(onDone: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(4000)
        onDone()
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp)
    ) {
        Spacer(Modifier.height(120.dp))
        Text("🎉", fontSize = 64.sp)
        Text(
            "نگهبان قانع شد!",
            fontFamily = lalezarFont,
            fontSize = 30.sp,
            color = Blue600,
            textAlign = TextAlign.Center
        )
        Text(
            "قفل تمرکز باز می‌شود…",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onDone) { Text("بازگشت به گوشی 🚀") }
    }
}

/** تبدیل تصویر انتخابی به Base64 (حداکثر ۱۰۲۴ پیکسل) */
private fun decodeToBase64Jpeg(context: android.content.Context, uri: Uri): String? {
    return try {
        val bmp = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it)
        } ?: return null
        val maxSide = 1024
        val scale = minOf(
            1f,
            maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        )
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt(),
                (bmp.height * scale).toInt(),
                true
            )
        } else bmp
        val bos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    } catch (e: Exception) {
        null
    }
}
