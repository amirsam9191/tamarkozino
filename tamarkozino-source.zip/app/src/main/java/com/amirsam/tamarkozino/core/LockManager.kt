package com.amirsam.tamarkozino.core

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import com.amirsam.tamarkozino.lock.GuardianService
import com.amirsam.tamarkozino.lock.LockScreenActivity
import com.amirsam.tamarkozino.util.formatHm
import com.amirsam.tamarkozino.util.nowMs
import org.json.JSONObject

/**
 * مدیر وضعیت قفل تمرکز
 */
object LockManager {

    fun isLocked(): Boolean = Prefs.lockActive

    /** باقی‌مانده قفل زمان‌دار به میلی‌ثانیه؛ null یعنی قفل ابدی */
    fun remainingMs(): Long? {
        if (!Prefs.lockActive) return 0L
        if (Prefs.lockEternal) return null
        return (Prefs.lockEndMs - nowMs()).coerceAtLeast(0L)
    }

    fun startTimedLock(context: Context, minutes: Int, reason: String) {
        val mins = minutes.coerceAtLeast(1)
        Prefs.lockActive = true
        Prefs.lockEternal = false
        Prefs.lockEndMs = nowMs() + mins * 60_000L
        Prefs.lockTotalMs = mins * 60_000L
        Prefs.lockReason = reason
        applyEnforcements(context)
        GuardianService.ensureRunning(context)
        LockScreenActivity.show(context)
        GuardianService.notifyEvent(
            context,
            "قفل تمرکز آغاز شد 🧘",
            "به مدت ${mins.formatHm()} گوشی در حالت تمرکز است. موفق باشی! 🚀"
        )
    }

    fun startEternal(context: Context, reason: String) {
        Prefs.lockActive = true
        Prefs.lockEternal = true
        Prefs.lockEndMs = 0L
        Prefs.lockTotalMs = 0L
        Prefs.lockReason = reason
        applyEnforcements(context)
        GuardianService.ensureRunning(context)
        LockScreenActivity.show(context)
        GuardianService.notifyEvent(
            context,
            "قفل ابدی فعال شد ♾",
            "گوشی تا وقتی محرک باز شدن رخ ندهد در حالت تمرکز می‌ماند."
        )
    }

    fun unlock(context: Context, reason: String) {
        if (!Prefs.lockActive) return
        Prefs.lockActive = false
        Prefs.lockEternal = false
        Prefs.lockEndMs = 0L
        Prefs.lastUnlockReason = reason
        restoreEnforcements(context)
        GuardianService.notifyEvent(context, "قفل باز شد 🔓", reason)
    }

    /** پایان قفل زمان‌دار در صورت رسیدن به موعد */
    fun maybeEndTimed(context: Context) {
        if (Prefs.lockActive && !Prefs.lockEternal && nowMs() >= Prefs.lockEndMs) {
            unlock(context, "پایان زمان تمرکز ⏰ — آفرین! 🎉")
        }
    }

    // ---------- اجرای محدودیت‌های صدا و اعلان ----------

    fun applyEnforcements(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (Prefs.savedVolumesJson.isEmpty()) {
            try {
                val saved = JSONObject()
                saved.put("ring", am.getStreamVolume(AudioManager.STREAM_RING))
                saved.put("music", am.getStreamVolume(AudioManager.STREAM_MUSIC))
                saved.put("notif", am.getStreamVolume(AudioManager.STREAM_NOTIFICATION))
                saved.put("system", am.getStreamVolume(AudioManager.STREAM_SYSTEM))
                saved.put("alarm", am.getStreamVolume(AudioManager.STREAM_ALARM))
                saved.put("mode", am.ringerMode)
                Prefs.savedVolumesJson = saved.toString()
            } catch (e: Exception) {
                // نادیده بگیر
            }
        }

        val needMute = Prefs.forceMute || Prefs.airplaneMode
        if (needMute) {
            setVolume(am, AudioManager.STREAM_RING, 0)
            setVolume(am, AudioManager.STREAM_MUSIC, 0)
            setVolume(am, AudioManager.STREAM_NOTIFICATION, 0)
            setVolume(am, AudioManager.STREAM_SYSTEM, 0)
            if (Prefs.forceMute) setVolume(am, AudioManager.STREAM_ALARM, 0)
            try {
                am.ringerMode = AudioManager.RINGER_MODE_SILENT
            } catch (e: Exception) {
                // نادیده بگیر
            }
        }

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val needDnd = Prefs.airplaneMode || Prefs.blockRinger || !Prefs.notificationsInLock
        if (needDnd && nm.isNotificationPolicyAccessGranted) {
            if (Prefs.prevDndFilter == -1) {
                Prefs.prevDndFilter = try {
                    nm.currentInterruptionFilter
                } catch (e: Exception) {
                    -1
                }
            }
            try {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            } catch (e: Exception) {
                // نادیده بگیر
            }
        }
    }

    fun restoreEnforcements(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        if (Prefs.savedVolumesJson.isNotEmpty()) {
            try {
                val saved = JSONObject(Prefs.savedVolumesJson)
                setVolume(am, AudioManager.STREAM_RING, saved.optInt("ring"))
                setVolume(am, AudioManager.STREAM_MUSIC, saved.optInt("music"))
                setVolume(am, AudioManager.STREAM_NOTIFICATION, saved.optInt("notif"))
                setVolume(am, AudioManager.STREAM_SYSTEM, saved.optInt("system"))
                setVolume(am, AudioManager.STREAM_ALARM, saved.optInt("alarm"))
                when (saved.optInt("mode")) {
                    AudioManager.RINGER_MODE_SILENT -> am.ringerMode = AudioManager.RINGER_MODE_SILENT
                    AudioManager.RINGER_MODE_VIBRATE -> am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                    else -> am.ringerMode = AudioManager.RINGER_MODE_NORMAL
                }
            } catch (e: Exception) {
                // نادیده بگیر
            }
            Prefs.savedVolumesJson = ""
        }

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Prefs.prevDndFilter != -1 && nm.isNotificationPolicyAccessGranted) {
            try {
                nm.setInterruptionFilter(Prefs.prevDndFilter)
            } catch (e: Exception) {
                // نادیده بگیر
            }
            Prefs.prevDndFilter = -1
        }
    }

    private fun setVolume(am: AudioManager, stream: Int, vol: Int) {
        try {
            val max = am.getStreamMaxVolume(stream)
            am.setStreamVolume(stream, vol.coerceIn(0, max), 0)
        } catch (e: Exception) {
            // نادیده بگیر
        }
    }
}
