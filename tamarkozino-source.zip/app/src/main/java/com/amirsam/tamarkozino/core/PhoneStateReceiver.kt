package com.amirsam.tamarkozino.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

/**
 * محرک باز شدن قفل ابدی: تماس ورودی
 */
class PhoneStateReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        if (!Prefs.lockActive || !Prefs.lockEternal) return
        val cfg = Prefs.eternalConfig()
        if (!cfg.callUnlock) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state == TelephonyManager.EXTRA_STATE_RINGING) {
            LockManager.unlock(context, "تماس ورودی 📞")
        }
    }
}
