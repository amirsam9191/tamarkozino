package com.amirsam.tamarkozino.core

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * مخزن تنظیمات تمرکزینو — همه‌ی وضعیت‌ها و پیکربندی‌ها
 */
object Prefs {

    lateinit var appContext: Context
        private set

    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        appContext = context.applicationContext
        sp = appContext.getSharedPreferences("tamarkozino", Context.MODE_PRIVATE)
    }

    private fun editor() = sp.edit()

    // ---------- وضعیت قفل ----------

    var lockActive: Boolean
        get() = sp.getBoolean("lock_active", false)
        set(v) = editor().putBoolean("lock_active", v).apply()

    var lockEternal: Boolean
        get() = sp.getBoolean("lock_eternal", false)
        set(v) = editor().putBoolean("lock_eternal", v).apply()

    var lockEndMs: Long
        get() = sp.getLong("lock_end", 0L)
        set(v) = editor().putLong("lock_end", v).apply()

    /** کل مدت قفل زمان‌دار برای نمایش حلقه‌ی پیشرفت */
    var lockTotalMs: Long
        get() = sp.getLong("lock_total", 0L)
        set(v) = editor().putLong("lock_total", v).apply()

    var lockReason: String
        get() = sp.getString("lock_reason", "") ?: ""
        set(v) = editor().putString("lock_reason", v).apply()

    var lastUnlockReason: String
        get() = sp.getString("last_unlock_reason", "") ?: ""
        set(v) = editor().putString("last_unlock_reason", v).apply()

    // ---------- برنامه‌های مجاز ----------

    fun allowedApps(): Set<String> = sp.getStringSet("allowed_apps", emptySet()) ?: emptySet()

    fun setAllowedApps(apps: Set<String>) {
        editor().putStringSet("allowed_apps", apps.toSet()).apply()
    }

    // ---------- تنظیمات هنگام قفل ----------

    var forceMute: Boolean
        get() = sp.getBoolean("force_mute", false)
        set(v) = editor().putBoolean("force_mute", v).apply()

    var blockRinger: Boolean
        get() = sp.getBoolean("block_ringer", false)
        set(v) = editor().putBoolean("block_ringer", v).apply()

    var airplaneMode: Boolean
        get() = sp.getBoolean("airplane", false)
        set(v) = editor().putBoolean("airplane", v).apply()

    var notificationsInLock: Boolean
        get() = sp.getBoolean("notif_in_lock", true)
        set(v) = editor().putBoolean("notif_in_lock", v).apply()

    var smsFromNotification: Boolean
        get() = sp.getBoolean("sms_from_notif", false)
        set(v) = editor().putBoolean("sms_from_notif", v).apply()

    /** پایش تهاجمی: سرعت پوشش‌دهی بالاتر (چرخه‌ی ۱۵۰ms) با هزینه باتری */
    var aggressiveWatch: Boolean
        get() = sp.getBoolean("aggressive", true)
        set(v) = editor().putBoolean("aggressive", v).apply()

    /** روش قفل: سنجاق کردن صفحه (Screen Pinning) */
    var lockPinning: Boolean
        get() = sp.getBoolean("pinning", false)
        set(v) = editor().putBoolean("pinning", v).apply()

    /** رفتار دکمه برگشت در صفحه قفل: نمایش پیام انگیزشی */
    var backMotivate: Boolean
        get() = sp.getBoolean("back_motivate", false)
        set(v) = editor().putBoolean("back_motivate", v).apply()

    // ---------- ریست شمارنده‌ها ----------

    var resetAfterReaction: Boolean
        get() = sp.getBoolean("reset_after_reaction", true)
        set(v) = editor().putBoolean("reset_after_reaction", v).apply()

    var dailyResetEnabled: Boolean
        get() = sp.getBoolean("daily_reset", false)
        set(v) = editor().putBoolean("daily_reset", v).apply()

    /** دقیقه‌ی روز برای ریست روزانه (پیش‌فرض ۰۰:۰۰) */
    var dailyResetMinute: Int
        get() = sp.getInt("daily_reset_min", 0)
        set(v) = editor().putInt("daily_reset_min", v).apply()

    var lastDailyResetDay: String
        get() = sp.getString("last_daily_reset_day", "") ?: ""
        set(v) = editor().putString("last_daily_reset_day", v).apply()

    // ---------- داده‌ها ----------

    var resetEpochMs: Long
        get() = sp.getLong("reset_epoch", 0L)
        set(v) = editor().putLong("reset_epoch", v).apply()

    fun rules(): MutableList<Rule> {
        val arr = JSONArray(sp.getString("rules", "[]") ?: "[]")
        val list = mutableListOf<Rule>()
        for (i in 0 until arr.length()) {
            list.add(Rule.fromJson(arr.optJSONObject(i) ?: continue))
        }
        return list
    }

    fun setRules(rules: List<Rule>) {
        val arr = JSONArray()
        rules.forEach { arr.put(it.toJson()) }
        editor().putString("rules", arr.toString()).apply()
    }

    fun schedules(): MutableList<Schedule> {
        val arr = JSONArray(sp.getString("schedules", "[]") ?: "[]")
        val list = mutableListOf<Schedule>()
        for (i in 0 until arr.length()) {
            list.add(Schedule.fromJson(arr.optJSONObject(i) ?: continue))
        }
        return list
    }

    fun setSchedules(schedules: List<Schedule>) {
        val arr = JSONArray()
        schedules.forEach { arr.put(it.toJson()) }
        editor().putString("schedules", arr.toString()).apply()
    }

    fun aiConfig(): AiConfig {
        val raw = sp.getString("ai", null) ?: return AiConfig()
        return try {
            AiConfig.fromJson(JSONObject(raw))
        } catch (e: Exception) {
            AiConfig()
        }
    }

    fun setAiConfig(cfg: AiConfig) {
        editor().putString("ai", cfg.toJson().toString()).apply()
    }

    fun eternalConfig(): EternalConfig {
        val raw = sp.getString("eternal", null) ?: return EternalConfig()
        return try {
            EternalConfig.fromJson(JSONObject(raw))
        } catch (e: Exception) {
            EternalConfig()
        }
    }

    fun setEternalConfig(cfg: EternalConfig) {
        editor().putString("eternal", cfg.toJson().toString()).apply()
    }

    // ---------- شمارنده‌های ردیابی ----------

    /** بازه‌های روشن بودن صفحه به شکل [شروع، پایان] */
    fun screenIntervals(): MutableList<LongArray> {
        val arr = JSONArray(sp.getString("screen_intervals", "[]") ?: "[]")
        val list = mutableListOf<LongArray>()
        for (i in 0 until arr.length()) {
            val pair = arr.optJSONArray(i) ?: continue
            if (pair.length() >= 2) list.add(longArrayOf(pair.optLong(0), pair.optLong(1)))
        }
        return list
    }

    fun setScreenIntervals(intervals: List<LongArray>) {
        val arr = JSONArray()
        intervals.forEach { iv -> arr.put(JSONArray().put(iv[0]).put(iv[1])) }
        editor().putString("screen_intervals", arr.toString()).apply()
    }

    fun addScreenInterval(start: Long, end: Long) {
        val list = screenIntervals()
        list.add(longArrayOf(start, end))
        setScreenIntervals(list)
    }

    /** شروع بازه‌ی بازِ روشن بودن صفحه (۰ یعنی صفحه خاموش است) */
    var screenOpenSince: Long
        get() = sp.getLong("screen_open_since", 0L)
        set(v) = editor().putLong("screen_open_since", v).apply()

    /** لحظه‌های روشن شدن صفحه (برای شمارش) */
    fun unlockTimes(): MutableList<Long> {
        val arr = JSONArray(sp.getString("unlock_times", "[]") ?: "[]")
        val list = mutableListOf<Long>()
        for (i in 0 until arr.length()) list.add(arr.optLong(i))
        return list
    }

    fun addUnlockTime(t: Long) {
        val list = unlockTimes()
        list.add(t)
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        editor().putString("unlock_times", arr.toString()).apply()
    }

    /** قوانینی که در این دوره اجرا شده‌اند */
    fun firedRules(): Set<String> = sp.getStringSet("fired_rules", emptySet()) ?: emptySet()

    fun markRuleFired(id: Long) {
        val set = firedRules().toMutableSet()
        set.add("$id")
        editor().putStringSet("fired_rules", set).apply()
    }

    fun clearFiredRules() {
        editor().putStringSet("fired_rules", emptySet<String>()).apply()
    }

    /** برنامه‌های روزانه‌ای که امروز پرسیده شده‌اند (schedId:dayKey) */
    fun askedSchedules(): Set<String> = sp.getStringSet("asked_scheds", emptySet()) ?: emptySet()

    fun markScheduleAsked(schedId: Long, dayKey: String) {
        val set = askedSchedules().toMutableSet()
        set.add("$schedId:$dayKey")
        editor().putStringSet("asked_scheds", set).apply()
    }

    fun clearAskedSchedulesOlderThan(dayKey: String) {
        val set = askedSchedules().filterTo(mutableSetOf()) { it.endsWith(":$dayKey") }
        editor().putStringSet("asked_scheds", set).apply()
    }

    // ---------- پشتیبان صدا ----------

    var savedVolumesJson: String
        get() = sp.getString("saved_volumes", "") ?: ""
        set(v) = editor().putString("saved_volumes", v).apply()

    var prevDndFilter: Int
        get() = sp.getInt("prev_dnd", -1)
        set(v) = editor().putInt("prev_dnd", v).apply()

    /** ریست کامل شمارنده‌ها (بعد از واکنش یا ریست روزانه) */
    fun resetCounters(now: Long) {
        resetEpochMs = now
        setScreenIntervals(emptyList())
        screenOpenSince = if (screenOpenSince != 0L) now else 0L
        editor().putString("unlock_times", "[]").apply()
        clearFiredRules()
    }
}
