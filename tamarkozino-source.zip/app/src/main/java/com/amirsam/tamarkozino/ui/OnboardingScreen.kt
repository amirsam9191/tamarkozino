package com.amirsam.tamarkozino.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.amirsam.tamarkozino.core.UsageTracker
import com.amirsam.tamarkozino.lock.LockAccessibilityService

/**
 * صفحه‌ی فعال‌سازی دسترسی‌ها — با راهنمای مخصوص سامسونگ
 */
@Composable
fun OnboardingScreen(nav: NavController) {
    val context = LocalContext.current

    var overlayOn by remember { mutableStateOf(false) }
    var a11yOn by remember { mutableStateOf(false) }
    var usageOn by remember { mutableStateOf(false) }
    var dndOn by remember { mutableStateOf(false) }
    var notifOn by remember { mutableStateOf(true) }
    var phoneOn by remember { mutableStateOf(false) }

    fun refresh() {
        overlayOn = Settings.canDrawOverlays(context)
        a11yOn = LockAccessibilityService.isRunning()
        usageOn = UsageTracker.hasUsageAccess(context)
        dndOn = try {
            val nm = context.getSystemService(android.app.NotificationManager::class.java)
            nm?.isNotificationPolicyAccessGranted ?: false
        } catch (e: Exception) {
            false
        }
        notifOn = if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else true
        phoneOn = ContextCompat.checkSelfPermission(
            context, Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
    }

    refresh()

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val notifRequest = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refresh() }
    val phoneRequest = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refresh() }

    fun open(action: String, extra: Uri? = null) {
        try {
            val intent = Intent(action)
            if (extra != null) intent.data = extra
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "صفحه‌ی تنظیمات باز نشد 😕", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text(
            "دسترسی‌ها و مجوزها 🔑",
            fontFamily = com.amirsam.tamarkozino.ui.theme.lalezarFont,
            fontSize = 30.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "برای قفلِ واقعی و پوشش سریع، این چند دسترسی لازم است؛ وضعیت‌ها پس از بازگشت از تنظیمات خودکار به‌روز می‌شوند ✅",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(14.dp))

        LazyColumn(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
            item {
                PermissionCard(
                    emoji = "🔔",
                    title = "اعلان‌های اپ",
                    desc = "برای اعلان‌های شروع و پایان تمرکز (اندروید ۱۳ و بالاتر)",
                    granted = notifOn,
                    actionText = "دادن مجوز"
                ) {
                    if (Build.VERSION.SDK_INT >= 33) {
                        notifRequest.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else refresh()
                }
            }
            item {
                PermissionCard(
                    emoji = "🖼",
                    title = "نمایش روی دیگر اپ‌ها",
                    desc = "قلبِ قفل: اجازه‌ی آوردن صفحه‌ی قفل روی برنامه‌های دیگر",
                    granted = overlayOn,
                    actionText = "فعال‌سازی"
                ) {
                    open(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                }
            }
            item {
                PermissionCard(
                    emoji = "♿",
                    title = "سرویس دسترسی‌پذیری",
                    desc = "برای تشخیص لحظه‌ای جابه‌جایی بین اپ‌ها و پوشش سریع (~۱۰۰-۳۰۰ms). در صفحه‌ی باز‌شده سرویس «تمرکزینو» را روشن کن.",
                    granted = a11yOn,
                    actionText = "فعال‌سازی"
                ) {
                    open(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                }
            }
            item {
                PermissionCard(
                    emoji = "📊",
                    title = "دسترسی وضعیت استفاده",
                    desc = "برای قوانین استفاده از برنامه‌ها و شمارش مصرف روزانه",
                    granted = usageOn,
                    actionText = "فعال‌سازی"
                ) {
                    open(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                }
            }
            item {
                PermissionCard(
                    emoji = "🔕",
                    title = "Do Not Disturb",
                    desc = "برای گزینه‌های بی‌صدا کردن زنگ و اعلان‌ها هنگام قفل",
                    granted = dndOn,
                    actionText = "فعال‌سازی"
                ) {
                    open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                }
            }
            item {
                PermissionCard(
                    emoji = "📞",
                    title = "تشخیص تماس",
                    desc = "برای باز شدن قفل ابدی وقتی به گوشی‌ات زنگ می‌خورد",
                    granted = phoneOn,
                    actionText = "دادن مجوز"
                ) {
                    phoneRequest.launch(Manifest.permission.READ_PHONE_STATE)
                }
            }
            item {
                // نکته باتری مخصوص سامسونگ
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "نکته‌ی مهم برای گوشی‌های سامسونگ 📱",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "۱. تنظیمات ← باتری ← محدودیت پس‌زمینه ← تمرکزینو ← «بدون محدودیت»\n" +
                                "۲. تنظیمات ← باتری ← «Optimisation استفاده از باتری» ← تمرکزینو را از حالت خواب بدر آور\n" +
                                "۳. One UI 6/7: تنظیمات ← برنامه‌ها ← تمرکزینو ← باتری ← Unrestricted\n" +
                                "۴. اعلان همیشگی «تمرکزینو در حال نگهبانی است» باید نمایان باشد — این یعنی سرویس زنده است ✅",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        OutlinedButton(
            onClick = { nav.popBackStack() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("بازگشت") }

        Spacer(Modifier.height(8.dp))
        SignatureFooter()
    }
}

@Composable
private fun PermissionCard(
    emoji: String,
    title: String,
    desc: String,
    granted: Boolean,
    actionText: String,
    onAction: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Text(emoji, fontSize = 26.sp)
            Spacer(Modifier.height(0.dp))
            Column(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp)
            ) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(
                    desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (granted) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "فعال است ✅",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            if (!granted) {
                Button(onClick = onAction) { Text(actionText) }
            } else {
                Text("✔", color = MaterialTheme.colorScheme.primary, fontSize = 20.sp)
            }
        }
    }
}
