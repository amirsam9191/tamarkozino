package com.amirsam.tamarkozino.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.security.MessageDigest

/** ابزارهای مشترک: اعداد فارسی، قالب زمان، هش و… */

private val FA_DIGITS = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

fun String.toFaDigits(): String {
    val sb = StringBuilder()
    for (c in this) {
        if (c.isDigit()) sb.append(FA_DIGITS[c - '0']) else sb.append(c)
    }
    return sb.toString()
}

fun Int.toFa(): String = this.toString().toFaDigits()

/** قالب شمارش معکوس ۰۰:۱۲:۳۴ */
fun Long.formatCountdown(): String {
    val total = (this / 1000).coerceAtLeast(0)
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s).toFaDigits()
}

/** "۱ ساعت و ۲۰ دقیقه" یا "۴۵ دقیقه" */
fun Int.formatHm(): String {
    val h = this / 60
    val m = this % 60
    val parts = mutableListOf<String>()
    if (h > 0) parts.add("${h.toFa()} ساعت")
    if (m > 0 || h == 0) parts.add("${m.toFa()} دقیقه")
    return parts.joinToString(" و ")
}

/** دقیقه‌ی روز از یک زمان (UTC-independent؛ بر اساس تقویم محلی) */
fun minuteOfDayOf(ts: Long): Int {
    val cal = Calendar.getInstance()
    cal.timeInMillis = ts
    return cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
}

/** برچسب ساعت "۱۵:۳۰" از دقیقه‌ی روز */
fun Int.toTimeLabel(): String {
    val h = this / 60
    val m = this % 60
    return String.format(Locale.US, "%02d:%02d", h, m).toFaDigits()
}

/** کلید روز برای تفکیک روزانه */
fun dayKeyOf(ts: Long): String {
    val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    return fmt.format(Date(ts))
}

fun nowMs(): Long = System.currentTimeMillis()

fun sha256Hex(input: String): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val bytes = digest.digest(input.toByteArray(Charsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
}

/** نرمال‌سازی جواب معما: حذف فاصله‌ها و علامت‌ها و یکسان‌سازی */
fun normalizeAnswer(input: String): String {
    return input.trim()
        .replace(" ", "")
        .replace("‌", "") // نیم‌فاصله
        .replace("ي", "ی")
        .replace("ك", "ک")
        .lowercase()
}
