package com.amirsam.tamarkozino.core

import android.content.Context
import com.amirsam.tamarkozino.lock.PromptActivity
import com.amirsam.tamarkozino.util.dayKeyOf
import com.amirsam.tamarkozino.util.minuteOfDayOf
import com.amirsam.tamarkozino.util.nowMs

/**
 * موتور قوانین هوشمند و برنامه‌های روزانه
 */
object RulesEngine {

    /** ارزیابی قوانین محرک → واکنش؛ فقط وقتی قفل فعال نیست */
    fun evaluateRules(context: Context): Boolean {
        if (Prefs.lockActive) return false
        UsageTracker.ensureEpoch()
        for (rule in Prefs.rules()) {
            if (!rule.enabled) continue
            if ("${rule.id}" in Prefs.firedRules()) continue
            val measured = measure(rule, context)
            val limit = threshold(rule)
            if (measured >= limit) {
                fire(context, rule)
                return true
            }
        }
        return false
    }

    private fun threshold(rule: Rule): Long =
        if (rule.trigger.usesCount) rule.unlockThreshold.toLong()
        else rule.thresholdMinutes * 60_000L

    private fun measure(rule: Rule, context: Context): Long {
        val ws = if (rule.trigger.usesWindow) rule.windowStart else null
        val we = if (rule.trigger.usesWindow) rule.windowEnd else null
        return when (rule.trigger) {
            TriggerKind.APP_USAGE_DAILY, TriggerKind.APP_USAGE_WINDOW ->
                UsageTracker.appUsageMs(context, rule.apps.toSet(), ws, we)
            TriggerKind.TOTAL_USAGE_DAILY, TriggerKind.TOTAL_USAGE_WINDOW ->
                UsageTracker.totalUsageMs(context, ws, we)
            TriggerKind.SCREEN_ON_DAILY, TriggerKind.SCREEN_ON_WINDOW ->
                UsageTracker.screenOnMs(ws, we)
            TriggerKind.UNLOCKS_DAILY, TriggerKind.UNLOCKS_WINDOW ->
                UsageTracker.unlockCount(ws, we).toLong()
        }
    }

    private fun fire(context: Context, rule: Rule) {
        Prefs.markRuleFired(rule.id)
        val reason = "قانون هوشمند ⚖️"
        when (rule.reaction) {
            ReactionKind.TIMED -> LockManager.startTimedLock(context, rule.lockMinutes, reason)
            ReactionKind.FORCED_CHOOSE -> PromptActivity.showForcedChoose(
                context, rule.forcedMinMinutes, rule.forcedMaxMinutes, reason
            )
            ReactionKind.ETERNAL -> LockManager.startEternal(context, reason)
        }
        if (Prefs.resetAfterReaction) {
            Prefs.resetCounters(nowMs())
        }
    }

    /** ارزیابی برنامه‌های روزانه (ساعت‌بندی) */
    fun evaluateSchedules(context: Context): Boolean {
        if (Prefs.lockActive) return false
        val now = nowMs()
        val day = dayKeyOf(now)
        val minute = minuteOfDayOf(now)

        for (s in Prefs.schedules()) {
            if (!s.enabled) continue
            val askedKey = "${s.id}:$day"

            when (s.kind) {
                ScheduleKind.WINDOW_LOCK -> {
                    val start = s.windowStart
                    val end = s.windowEnd
                    val inWindow =
                        if (end >= start) minute >= start && minute < end
                        else minute >= start || minute < end
                    if (inWindow) {
                        val remaining =
                            if (end >= start) end - minute
                            else (24 * 60 - minute + end)
                        LockManager.startTimedLock(
                            context,
                            remaining.coerceAtLeast(1),
                            "برنامه‌ی روزانه 📅"
                        )
                        return true
                    }
                }

                ScheduleKind.ASK_AT_TIME -> {
                    if (minute >= s.timeMinute && minute <= s.timeMinute + 5 && askedKey !in Prefs.askedSchedules()) {
                        Prefs.markScheduleAsked(s.id, day)
                        PromptActivity.showAsk(context, s.askDurationMinutes, "برنامه‌ی روزانه 📅")
                        return true
                    }
                }

                ScheduleKind.FORCED_LOCK_AT_TIME -> {
                    if (minute >= s.timeMinute && minute <= s.timeMinute + 5 && askedKey !in Prefs.askedSchedules()) {
                        Prefs.markScheduleAsked(s.id, day)
                        LockManager.startTimedLock(
                            context,
                            s.durationMinutes,
                            "برنامه‌ی روزانه 📅 (اجباری)"
                        )
                        return true
                    }
                }

                ScheduleKind.FORCED_CHOOSE_AT_TIME -> {
                    if (minute >= s.timeMinute && minute <= s.timeMinute + 5 && askedKey !in Prefs.askedSchedules()) {
                        Prefs.markScheduleAsked(s.id, day)
                        PromptActivity.showForcedChoose(
                            context,
                            s.forcedMinMinutes,
                            s.forcedMaxMinutes,
                            "برنامه‌ی روزانه 📅 (اجباری)"
                        )
                        return true
                    }
                }
            }
        }
        return false
    }
}
