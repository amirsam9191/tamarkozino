package com.amirsam.tamarkozino

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.core.UsageTracker
import com.amirsam.tamarkozino.lock.GuardianService

class App : Application() {

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        UsageTracker.ensureEpoch()
        createChannels()
        // اگر قفلی فعال است، سرویس نگهبان را بیدار کن (مثلاً بعد از کشته شدن پروسه)
        if (Prefs.lockActive) {
            GuardianService.ensureRunning(this)
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        val guardian = NotificationChannel(
            GuardianService.CHANNEL_GUARDIAN,
            getString(R.string.guardian_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.guardian_channel_desc)
            setShowBadge(false)
        }
        val focus = NotificationChannel(
            GuardianService.CHANNEL_FOCUS,
            getString(R.string.focus_channel_name),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = getString(R.string.focus_channel_desc)
        }
        nm.createNotificationChannel(guardian)
        nm.createNotificationChannel(focus)
    }
}
