package com.amirsam.tamarkozino.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.amirsam.tamarkozino.core.AppList
import com.amirsam.tamarkozino.core.Prefs
import com.amirsam.tamarkozino.util.toFa
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * انتخاب برنامه‌های مجاز در زمان قفل
 */
@Composable
fun AllowedAppsScreen(nav: NavController) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<AppList.AppInfo>>(emptyList()) }
    var selected by remember { mutableStateOf(Prefs.allowedApps().toMutableSet()) }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            apps = AppList.ensureLoaded(context)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "برنامه‌های مجاز 📲",
                fontFamily = com.amirsam.tamarkozino.ui.theme.lalezarFont,
                fontSize = 30.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = { nav.popBackStack() }) { Text("بازگشت") }
        }
        Text(
            "${selected.size.toFa()} برنامه انتخاب شده — در زمان قفل فقط همین‌ها باز می‌مانند و آیکون‌شان در صفحه‌ی قفل نمایش داده می‌شود. با دکمه‌ی ریسنت‌ها هم فقط به همین‌ها دسترسی داری.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            placeholder = { Text("جستجوی برنامه…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                selected = apps.map { it.pkg }.toMutableSet()
                Prefs.setAllowedApps(selected)
            }) { Text("انتخاب همه") }
            OutlinedButton(onClick = {
                selected = mutableSetOf()
                Prefs.setAllowedApps(selected)
            }) { Text("هیچ‌کدام") }
        }

        Spacer(Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            val filtered = apps.filter {
                search.isBlank() || it.label.contains(search) || it.pkg.contains(search)
            }
            items(filtered) { app ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(10.dp)
                    ) {
                        if (app.icon != null) {
                            Image(
                                bitmap = app.icon.asImageBitmap(),
                                contentDescription = app.label,
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                            )
                        }
                        Column(
                            Modifier
                                .weight(1f)
                                .padding(horizontal = 10.dp)
                        ) {
                            Text(app.label, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                app.pkg,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Checkbox(
                            checked = app.pkg in selected,
                            onCheckedChange = { on ->
                                if (on) selected.add(app.pkg) else selected.remove(app.pkg)
                                Prefs.setAllowedApps(selected)
                            }
                        )
                    }
                }
            }
            item {
                if (apps.isEmpty()) {
                    Text(
                        "در حال بارگذاری فهرست برنامه‌ها…",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            item { SignatureFooter() }
        }
    }
}
