package com.amirsam.tamarkozino.core

import org.json.JSONArray
import org.json.JSONObject

/** درجه‌ی سخت‌گیری هوش مصنوعی در تأیید باز شدن قفل */
enum class Strictness(val label: String) {
    EASY("آسان — سریع قانع می‌شود"),
    MEDIUM("متوسط — مدرک منطقی می‌خواهد"),
    HARD("سخت — حداقل دو مدرک روشن می‌خواهد");

    companion object {
        fun of(name: String?): Strictness = entries.firstOrNull { it.name == name } ?: MEDIUM
    }
}

/** تنظیمات API هوش مصنوعی (سازگار با OpenAI) */
data class AiConfig(
    var baseUrl: String = "https://one-balance.amirsam919191.workers.dev/api/compat/",
    var chatPath: String = "chat/completions",
    var model: String = "google-ai-studio/gemini-3.1-flash-lite",
    var apiKey: String = "amirsam1391",
    var authHeader: String = "Authorization",
    var authScheme: String = "Bearer",
    var strictness: Strictness = Strictness.MEDIUM,
    var taskDescription: String = "کار روزانه‌ام را کامل انجام داده‌ام و پیشرفت واقعی داشته‌ام."
) {
    fun fullUrl(): String {
        val base = baseUrl.trim().trimEnd('/')
        val path = chatPath.trim().trim('/')
        return if (path.isEmpty()) base else "$base/$path"
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("baseUrl", baseUrl)
        put("chatPath", chatPath)
        put("model", model)
        put("apiKey", apiKey)
        put("authHeader", authHeader)
        put("authScheme", authScheme)
        put("strictness", strictness.name)
        put("taskDescription", taskDescription)
    }

    companion object {
        fun fromJson(o: JSONObject): AiConfig = AiConfig(
            baseUrl = o.optString("baseUrl", "https://one-balance.amirsam919191.workers.dev/api/compat/"),
            chatPath = o.optString("chatPath", "chat/completions"),
            model = o.optString("model", "google-ai-studio/gemini-3.1-flash-lite"),
            apiKey = o.optString("apiKey", "amirsam1391"),
            authHeader = o.optString("authHeader", "Authorization"),
            authScheme = o.optString("authScheme", "Bearer"),
            strictness = Strictness.of(o.optString("strictness", "MEDIUM")),
            taskDescription = o.optString("taskDescription", "کار روزانه‌ام را کامل انجام داده‌ام و پیشرفت واقعی داشته‌ام.")
        )
    }
}

/** پیکربندی قفل ابدی و روش‌های باز کردن آن */
data class EternalConfig(
    var callUnlock: Boolean = true,
    var rebootUnlock: Boolean = true,
    var pinEnabled: Boolean = false,
    var pinHash: String = "",
    var riddleEnabled: Boolean = false,
    var riddleQuestion: String = "",
    var riddleAnswer: String = "",
    var aiUnlock: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("callUnlock", callUnlock)
        put("rebootUnlock", rebootUnlock)
        put("pinEnabled", pinEnabled)
        put("pinHash", pinHash)
        put("riddleEnabled", riddleEnabled)
        put("riddleQuestion", riddleQuestion)
        put("riddleAnswer", riddleAnswer)
        put("aiUnlock", aiUnlock)
    }

    companion object {
        fun fromJson(o: JSONObject): EternalConfig = EternalConfig(
            callUnlock = o.optBoolean("callUnlock", true),
            rebootUnlock = o.optBoolean("rebootUnlock", true),
            pinEnabled = o.optBoolean("pinEnabled", false),
            pinHash = o.optString("pinHash", ""),
            riddleEnabled = o.optBoolean("riddleEnabled", false),
            riddleQuestion = o.optString("riddleQuestion", ""),
            riddleAnswer = o.optString("riddleAnswer", ""),
            aiUnlock = o.optBoolean("aiUnlock", false)
        )
    }
}

/** نوع محرک قانون */
enum class TriggerKind(val label: String, val usesApps: Boolean, val usesMinutes: Boolean, val usesCount: Boolean, val usesWindow: Boolean) {
    APP_USAGE_DAILY("استفاده از برنامه‌های انتخابی — در کل روز", true, true, false, false),
    APP_USAGE_WINDOW("استفاده از برنامه‌های انتخابی — در بازه‌ی ساعتی", true, true, false, true),
    TOTAL_USAGE_DAILY("استفاده کل گوشی — در کل روز", false, true, false, false),
    TOTAL_USAGE_WINDOW("استفاده کل گوشی — در بازه‌ی ساعتی", false, true, false, true),
    SCREEN_ON_DAILY("روشن بودن صفحه — در کل روز", false, true, false, false),
    SCREEN_ON_WINDOW("روشن بودن صفحه — در بازه‌ی ساعتی", false, true, false, true),
    UNLOCKS_DAILY("تعداد روشن‌کردن گوشی — در کل روز", false, false, true, false),
    UNLOCKS_WINDOW("تعداد روشن‌کردن گوشی — در بازه‌ی ساعتی", false, false, true, true);

    companion object {
        fun of(name: String?): TriggerKind = entries.firstOrNull { it.name == name } ?: APP_USAGE_DAILY
    }
}

/** نوع واکنش قانون */
enum class ReactionKind(val label: String) {
    TIMED("قفل زمان‌دار"),
    FORCED_CHOOSE("صفحه‌ی انتخاب زمان اجباری"),
    ETERNAL("قفل ابدی");

    companion object {
        fun of(name: String?): ReactionKind = entries.firstOrNull { it.name == name } ?: TIMED
    }
}

/** قانون هوشمند: محرک → واکنش */
data class Rule(
    var id: Long = System.currentTimeMillis(),
    var enabled: Boolean = true,
    var trigger: TriggerKind = TriggerKind.APP_USAGE_DAILY,
    var apps: MutableList<String> = mutableListOf(),
    var thresholdMinutes: Int = 30,
    var unlockThreshold: Int = 5,
    var windowStart: Int = 15 * 60,
    var windowEnd: Int = 16 * 60,
    var reaction: ReactionKind = ReactionKind.TIMED,
    var lockMinutes: Int = 60,
    var forcedMinMinutes: Int = 15,
    var forcedMaxMinutes: Int = 120
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("enabled", enabled)
        put("trigger", trigger.name)
        put("apps", JSONArray(apps))
        put("thresholdMinutes", thresholdMinutes)
        put("unlockThreshold", unlockThreshold)
        put("windowStart", windowStart)
        put("windowEnd", windowEnd)
        put("reaction", reaction.name)
        put("lockMinutes", lockMinutes)
        put("forcedMinMinutes", forcedMinMinutes)
        put("forcedMaxMinutes", forcedMaxMinutes)
    }

    companion object {
        fun fromJson(o: JSONObject): Rule = Rule(
            id = o.optLong("id", 0L),
            enabled = o.optBoolean("enabled", true),
            trigger = TriggerKind.of(o.optString("trigger")),
            apps = mutableListOf<String>().apply {
                val arr = o.optJSONArray("apps") ?: JSONArray()
                for (i in 0 until arr.length()) add(arr.optString(i))
            },
            thresholdMinutes = o.optInt("thresholdMinutes", 30),
            unlockThreshold = o.optInt("unlockThreshold", 5),
            windowStart = o.optInt("windowStart", 15 * 60),
            windowEnd = o.optInt("windowEnd", 16 * 60),
            reaction = ReactionKind.of(o.optString("reaction")),
            lockMinutes = o.optInt("lockMinutes", 60),
            forcedMinMinutes = o.optInt("forcedMinMinutes", 15),
            forcedMaxMinutes = o.optInt("forcedMaxMinutes", 120)
        )
    }
}

/** نوع برنامه‌ی روزانه */
enum class ScheduleKind(val label: String) {
    WINDOW_LOCK("قفل بازه‌ای هر روز (مثلاً ۱۵ تا ۱۶)"),
    ASK_AT_TIME("سؤال در ساعت مشخص (بله/خیر)"),
    FORCED_LOCK_AT_TIME("قفل اجباری در ساعت مشخص"),
    FORCED_CHOOSE_AT_TIME("صفحه‌ی انتخاب زمان اجباری در ساعت مشخص");

    companion object {
        fun of(name: String?): ScheduleKind = entries.firstOrNull { it.name == name } ?: ASK_AT_TIME
    }
}

/** برنامه‌ی روزانه */
data class Schedule(
    var id: Long = System.currentTimeMillis(),
    var enabled: Boolean = true,
    var kind: ScheduleKind = ScheduleKind.ASK_AT_TIME,
    var windowStart: Int = 15 * 60,
    var windowEnd: Int = 16 * 60,
    var timeMinute: Int = 15 * 60 + 30,
    var durationMinutes: Int = 60,
    var askDurationMinutes: Int = 60,
    var forcedMinMinutes: Int = 15,
    var forcedMaxMinutes: Int = 120
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("enabled", enabled)
        put("kind", kind.name)
        put("windowStart", windowStart)
        put("windowEnd", windowEnd)
        put("timeMinute", timeMinute)
        put("durationMinutes", durationMinutes)
        put("askDurationMinutes", askDurationMinutes)
        put("forcedMinMinutes", forcedMinMinutes)
        put("forcedMaxMinutes", forcedMaxMinutes)
    }

    companion object {
        fun fromJson(o: JSONObject): Schedule = Schedule(
            id = o.optLong("id", 0L),
            enabled = o.optBoolean("enabled", true),
            kind = ScheduleKind.of(o.optString("kind")),
            windowStart = o.optInt("windowStart", 15 * 60),
            windowEnd = o.optInt("windowEnd", 16 * 60),
            timeMinute = o.optInt("timeMinute", 15 * 60 + 30),
            durationMinutes = o.optInt("durationMinutes", 60),
            askDurationMinutes = o.optInt("askDurationMinutes", 60),
            forcedMinMinutes = o.optInt("forcedMinMinutes", 15),
            forcedMaxMinutes = o.optInt("forcedMaxMinutes", 120)
        )
    }
}
